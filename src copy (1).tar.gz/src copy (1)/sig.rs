//! File signatures the way Sysinternals Sigcheck (VirusTotal's "Signature info") checks them:
//! embedded Authenticode via WinVerifyTrust, then Windows catalog signatures. Offline: revocation is
//! checked against cached CRLs only, nothing is uploaded. Also: exe icons and NT device path mapping.
//!
//! WinVerifyTrust leaves the "does the file still match its signature" step to the PE SIP registered in
//! the registry, which malware can point at a function that always succeeds. So the Authenticode digest
//! of every embedded signature is also recomputed here, and the SIP registration itself is checked.
use crate::win::w;
use std::{
    collections::HashMap, ffi::c_void, fs, io::{Read, Seek, SeekFrom, Write}, path::{Path, PathBuf}, ptr::{null, null_mut},
    sync::{atomic::{AtomicBool, AtomicUsize, Ordering::Relaxed}, Mutex},
    time::UNIX_EPOCH,
};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Sig { Pending, Signed, Unsigned, Invalid, Expired, Revoked, NotFound, NoFile, Tampered }

impl Sig {
    const ALL: [Sig; 9] = [Sig::Pending, Sig::Signed, Sig::Unsigned, Sig::Invalid, Sig::Expired, Sig::Revoked, Sig::NotFound, Sig::NoFile, Sig::Tampered];
    pub fn label(self) -> &'static str {
        match self {
            Sig::Pending => "…", Sig::Signed => "Signed", Sig::Unsigned => "Unsigned", Sig::Invalid => "Invalid",
            Sig::Expired => "Expired", Sig::Revoked => "Revoked", Sig::NotFound => "Not Found", Sig::NoFile => "", Sig::Tampered => "Tampered",
        }
    }
    /// Signature present but not trustworthy, or none at all.
    pub fn untrusted(self) -> bool { matches!(self, Sig::Unsigned | Sig::Invalid | Sig::Expired | Sig::Revoked | Sig::Tampered) }
}

/// Result for one file. `catalog` = signed through a Windows catalog instead of an embedded signature.
#[derive(Clone)]
pub struct Check { pub sig: Sig, pub signer: String, pub catalog: bool }

// ---- Win32 ------------------------------------------------------------------------------------

#[repr(C)]
struct Guid(u32, u16, u16, [u8; 8]);
const GENERIC_VERIFY_V2: Guid = Guid(0x00AA_C56B, 0xCD44, 0x11D0, [0x8C, 0xC2, 0x00, 0xC0, 0x4F, 0xC2, 0x95, 0xEE]);
const DRIVER_ACTION_VERIFY: Guid = Guid(0xF750_E6C3, 0x38EE, 0x11D1, [0x85, 0xE5, 0x00, 0xC0, 0x4F, 0xC2, 0x95, 0xEE]);

#[repr(C)]
struct FileInfo { cb: u32, path: *const u16, h: isize, subject: *const Guid }
#[repr(C)]
struct CatInfo { cb: u32, ver: u32, cat_path: *const u16, tag: *const u16, member: *const u16, h: isize, hash: *const u8, cb_hash: u32, ctx: *const c_void, admin: isize }
#[repr(C)]
struct TrustData { cb: u32, policy: *const c_void, sip: *const c_void, ui: u32, revoke: u32, choice: u32, info: *const c_void, action: u32, state: isize, url: *const u16, prov: u32, ui_ctx: u32, settings: *const c_void }
#[repr(C)]
struct CatalogInfo { cb: u32, file: [u16; 260] }
#[repr(C)]
struct ShFileInfo { icon: isize, index: i32, attrs: u32, name: [u16; 260], typ: [u16; 80] }
#[repr(C)]
struct IconInfo { is_icon: i32, x: u32, y: u32, mask: isize, color: isize }
#[repr(C)]
struct Bitmap { typ: i32, w: i32, h: i32, wb: i32, planes: u16, bpp: u16, bits: *mut c_void }
#[repr(C)]
struct BmiHeader { size: u32, w: i32, h: i32, planes: u16, bpp: u16, comp: u32, size_img: u32, xppm: i32, yppm: i32, used: u32, important: u32, colors: [u32; 4] }

#[link(name = "wintrust", kind = "raw-dylib")]
unsafe extern "system" {
    fn WinVerifyTrust(hwnd: isize, action: *const Guid, data: *mut TrustData) -> i32;
    fn WTHelperProvDataFromStateData(state: isize) -> *mut c_void;
    fn WTHelperGetProvSignerFromChain(prov: *mut c_void, signer: u32, counter: i32, counter_idx: u32) -> *const u8;
    fn CryptCATAdminAcquireContext2(admin: *mut isize, subsystem: *const Guid, alg: *const u16, policy: *const c_void, flags: u32) -> i32;
    fn CryptCATAdminCalcHashFromFileHandle2(admin: isize, file: isize, cb: *mut u32, hash: *mut u8, flags: u32) -> i32;
    fn CryptCATAdminEnumCatalogFromHash(admin: isize, hash: *const u8, cb: u32, flags: u32, prev: *mut isize) -> isize;
    fn CryptCATCatalogInfoFromContext(cat: isize, info: *mut CatalogInfo, flags: u32) -> i32;
    fn CryptCATAdminReleaseCatalogContext(admin: isize, cat: isize, flags: u32) -> i32;
    fn CryptCATAdminReleaseContext(admin: isize, flags: u32) -> i32;
}
#[link(name = "crypt32", kind = "raw-dylib")]
unsafe extern "system" { fn CertGetNameStringW(cert: *const c_void, typ: u32, flags: u32, para: *const c_void, out: *mut u16, cch: u32) -> u32; }
#[link(name = "kernel32", kind = "raw-dylib")]
unsafe extern "system" {
    fn CreateFileW(name: *const u16, access: u32, share: u32, sa: *const c_void, disp: u32, flags: u32, tmpl: isize) -> isize;
    fn CloseHandle(h: isize) -> i32;
    fn QueryDosDeviceW(name: *const u16, out: *mut u16, max: u32) -> u32;
}
#[link(name = "shell32", kind = "raw-dylib")]
unsafe extern "system" { fn SHGetFileInfoW(path: *const u16, attrs: u32, info: *mut ShFileInfo, cb: u32, flags: u32) -> usize; }
#[link(name = "user32", kind = "raw-dylib")]
unsafe extern "system" {
    fn GetIconInfo(icon: isize, info: *mut IconInfo) -> i32;
    fn DestroyIcon(icon: isize) -> i32;
    fn GetDC(hwnd: isize) -> isize;
    fn ReleaseDC(hwnd: isize, dc: isize) -> i32;
}
#[link(name = "gdi32", kind = "raw-dylib")]
unsafe extern "system" {
    fn GetObjectW(h: isize, cb: i32, out: *mut c_void) -> i32;
    fn GetDIBits(dc: isize, bmp: isize, start: u32, lines: u32, bits: *mut c_void, bmi: *mut BmiHeader, usage: u32) -> i32;
    fn DeleteObject(h: isize) -> i32;
}
#[link(name = "ole32", kind = "raw-dylib")]
unsafe extern "system" { fn CoInitializeEx(r: *const c_void, flags: u32) -> i32; }
#[link(name = "bcrypt", kind = "raw-dylib")]
unsafe extern "system" {
    fn BCryptCreateHash(alg: isize, h: *mut isize, obj: *mut u8, cb_obj: u32, secret: *const u8, cb_secret: u32, flags: u32) -> i32;
    fn BCryptHashData(h: isize, input: *const u8, cb: u32, flags: u32) -> i32;
    fn BCryptFinishHash(h: isize, out: *mut u8, cb: u32, flags: u32) -> i32;
    fn BCryptDestroyHash(h: isize) -> i32;
}
#[link(name = "advapi32", kind = "raw-dylib")]
unsafe extern "system" { fn RegGetValueW(key: isize, sub: *const u16, value: *const u16, flags: u32, typ: *mut u32, data: *mut u16, cb: *mut u32) -> i32; }

// ---- verification ------------------------------------------------------------------------------

/// WinVerifyTrust with WINTRUST_ACTION_GENERIC_VERIFY_V2; returns the status and the leaf signer's name.
fn verify(choice: u32, info: *const c_void) -> (i32, String) {
    let mut d = TrustData {
        cb: size_of::<TrustData>() as u32, policy: null(), sip: null(), ui: 2 /*WTD_UI_NONE*/, revoke: 1 /*WTD_REVOKE_WHOLECHAIN*/,
        choice, info, action: 1 /*VERIFY*/, state: 0, url: null(),
        prov: 0x1000 | 0x80, // WTD_CACHE_ONLY_URL_RETRIEVAL (offline) | WTD_REVOCATION_CHECK_CHAIN_EXCLUDE_ROOT
        ui_ctx: 0, settings: null(),
    };
    unsafe {
        let rc = WinVerifyTrust(-1, &GENERIC_VERIFY_V2, &mut d);
        let signer = if d.state != 0 { signer(d.state) } else { String::new() };
        d.action = 2; // WTD_STATEACTION_CLOSE
        WinVerifyTrust(-1, &GENERIC_VERIFY_V2, &mut d);
        (rc, signer)
    }
}

unsafe fn signer(state: isize) -> String {
    unsafe {
        let prov = WTHelperProvDataFromStateData(state);
        if prov.is_null() { return String::new(); }
        let sg = WTHelperGetProvSignerFromChain(prov, 0, 0, 0);
        if sg.is_null() { return String::new(); }
        // CRYPT_PROVIDER_SGNR: csCertChain at +12, pasCertChain at +16; CRYPT_PROVIDER_CERT: pCert at +8
        let (count, chain) = (*(sg.add(12) as *const u32), *(sg.add(16) as *const *const u8));
        if count == 0 || chain.is_null() { return String::new(); }
        let cert = *(chain.add(8) as *const *const c_void);
        let mut buf = [0u16; 256];
        let n = CertGetNameStringW(cert, 4 /*CERT_NAME_SIMPLE_DISPLAY_TYPE*/, 0, null(), buf.as_mut_ptr(), 256) as usize;
        String::from_utf16_lossy(&buf[..n.saturating_sub(1)])
    }
}

fn classify(rc: i32) -> Sig {
    match rc as u32 {
        0 | 0x800B_010E | 0x8009_2013 => Sig::Signed, // revocation unknown offline: signature itself is valid
        0x800B_010C | 0x8009_2010 => Sig::Revoked,
        0x800B_0101 => Sig::Expired,
        0x800B_0100 | 0x800B_0003 | 0x800B_0001 => Sig::Unsigned, // no signature / unknown subject form
        0x8009_6010 | 0x8009_1007 => Sig::Tampered, // TRUST_E_BAD_DIGEST, CRYPT_E_HASH_VALUE: digest mismatch
        _ => Sig::Invalid,
    }
}

/// Embedded signature first; catalog (SHA-256 then SHA-1) when there is none. An embedded signature whose
/// digest does not match the file is Tampered, whatever WinVerifyTrust says.
pub fn check(path: &Path) -> Check {
    if !path.is_file() { return Check { sig: Sig::NotFound, signer: String::new(), catalog: false }; }
    let wp = w(&path.to_string_lossy());
    let fi = FileInfo { cb: size_of::<FileInfo>() as u32, path: wp.as_ptr(), h: 0, subject: null() };
    let (rc, signer) = verify(1 /*WTD_CHOICE_FILE*/, &fi as *const _ as _);
    match classify(rc) {
        Sig::Unsigned => catalog(&wp).unwrap_or(Check { sig: Sig::Unsigned, signer: String::new(), catalog: false }),
        _ if digest_matches(path) == Some(false) => Check { sig: Sig::Tampered, signer, catalog: false },
        sig => Check { sig, signer, catalog: false },
    }
}

/// One DER element: (tag, contents, rest).
fn tlv(b: &[u8]) -> Option<(u8, &[u8], &[u8])> {
    let (tag, l0) = (*b.first()?, *b.get(1)? as usize);
    let (len, hdr) = if l0 < 0x80 { (l0, 2) } else {
        let n = l0 & 0x7F;
        if n == 0 || n > 4 { return None; }
        (b.get(2..2 + n)?.iter().fold(0usize, |l, &x| l << 8 | x as usize), 2 + n)
    };
    let end = hdr.checked_add(len)?;
    Some((tag, b.get(hdr..end)?, &b[end..]))
}

/// PKCS#7 SignedData -> SpcIndirectDataContent -> DigestInfo: (digest algorithm OID, signed file digest).
fn signed_digest(p7: &[u8]) -> Option<(&[u8], &[u8])> {
    let (_, ci, _) = tlv(p7)?; // ContentInfo
    let (_, _, r) = tlv(ci)?; // signedData OID
    let (_, sd, _) = tlv(tlv(r)?.1)?; // [0] SignedData
    let (_, _, r) = tlv(sd)?; // version
    let (_, _, r) = tlv(r)?; // digestAlgorithms
    let (_, eci, _) = tlv(r)?; // encapContentInfo
    let (_, _, r) = tlv(eci)?; // SPC_INDIRECT_DATA OID
    let (_, idc, _) = tlv(tlv(r)?.1)?; // [0] SpcIndirectDataContent
    let (_, _, r) = tlv(idc)?; // SpcAttributeTypeAndOptionalValue
    let (_, di, _) = tlv(r)?; // DigestInfo
    let (_, ai, r) = tlv(di)?; // AlgorithmIdentifier
    let (_, oid, _) = tlv(ai)?;
    let (tag, digest, _) = tlv(r)?;
    (tag == 4).then_some((oid, digest))
}

/// Recomputes the PE Authenticode digest (whole file minus checksum, certificate directory entry and
/// certificate table) and compares it with the digest inside the embedded signature. None = not checkable.
pub fn digest_matches(path: &Path) -> Option<bool> {
    let mut f = fs::File::open(path).ok()?;
    let len = f.metadata().ok()?.len();
    let mut h = vec![0u8; 4096.min(len as usize)];
    f.read_exact(&mut h).ok()?;
    let u32_at = |o: usize| Some(u32::from_le_bytes(h.get(o..o + 4)?.try_into().ok()?));
    let pe = u32_at(0x3C)? as usize;
    if h.get(pe..pe + 4)? != b"PE\0\0" { return None; }
    let opt = pe + 24;
    let dirs = opt + if u16::from_le_bytes(h.get(opt..opt + 2)?.try_into().ok()?) == 0x20B { 112 } else { 96 };
    let (sum, entry) = (opt as u64 + 64, dirs as u64 + 4 * 8);
    let (cert_off, cert_size) = (u32_at(entry as usize)? as u64, u32_at(entry as usize + 4)? as u64);
    if cert_size < 8 || cert_off < entry + 8 || cert_off + cert_size > len { return None; }
    let mut table = vec![0u8; cert_size as usize];
    f.seek(SeekFrom::Start(cert_off)).ok()?;
    f.read_exact(&mut table).ok()?;
    let wlen = (u32::from_le_bytes(table[..4].try_into().ok()?) as usize).min(table.len());
    if u16::from_le_bytes(table[6..8].try_into().ok()?) != 2 { return None; } // WIN_CERT_TYPE_PKCS_SIGNED_DATA
    let (oid, want) = signed_digest(table.get(8..wlen)?)?;
    // BCrypt pseudo-handles (Windows 10+)
    let alg = match oid {
        [0x2B, 0x0E, 0x03, 0x02, 0x1A] => 0x31, // SHA-1
        [0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, n @ 1..=3] => 0x41 + 0x10 * (*n as isize - 1), // SHA-256/384/512
        [0x2A, 0x86, 0x48, 0x86, 0xF7, 0x0D, 0x02, 0x05] => 0x21, // MD5
        _ => return None,
    };
    let ranges = [(0, sum), (sum + 4, entry), (entry + 8, cert_off), (cert_off + cert_size, len)];
    let mut got = vec![0u8; want.len()];
    unsafe {
        let mut hh = 0;
        if BCryptCreateHash(alg, &mut hh, null_mut(), 0, null(), 0, 0) != 0 { return None; }
        let mut buf = vec![0u8; 1 << 20];
        let mut ok = true;
        'r: for (a, b) in ranges {
            if b <= a { continue; }
            if f.seek(SeekFrom::Start(a)).is_err() { ok = false; break; }
            let mut left = b - a;
            while left > 0 {
                let n = left.min(buf.len() as u64) as usize;
                if f.read_exact(&mut buf[..n]).is_err() { ok = false; break 'r; }
                BCryptHashData(hh, buf.as_ptr(), n as u32, 0);
                left -= n as u64;
            }
        }
        ok &= BCryptFinishHash(hh, got.as_mut_ptr(), got.len() as u32, 0) == 0;
        BCryptDestroyHash(hh);
        ok.then(|| got == want)
    }
}

/// Registry hooks that make WinVerifyTrust accept any PE: the PE SIP and the Authenticode final policy must
/// point at WINTRUST.DLL. Returns a description of every redirected entry.
pub fn hijacks() -> Vec<String> {
    let reg = |key: &str, value: &str| -> String {
        let (k, v, mut buf, mut cb) = (w(key), w(value), [0u16; 260], 520u32);
        let ok = unsafe { RegGetValueW(0x8000_0002u32 as i32 as isize, k.as_ptr(), v.as_ptr(), 0x6 /*RRF_RT_REG_SZ|EXPAND_SZ*/, null_mut(), buf.as_mut_ptr(), &mut cb) } == 0;
        if ok { String::from_utf16_lossy(&buf[..(cb as usize / 2).saturating_sub(1)]) } else { String::new() }
    };
    let mut out = vec![];
    for node in [r"SOFTWARE", r"SOFTWARE\WOW6432Node"] {
        let sip = format!(r"{node}\Microsoft\Cryptography\OID\EncodingType 0");
        for (k, func) in [("CryptSIPDllVerifyIndirectData", "CryptSIPVerifyIndirectData"), ("CryptSIPDllGetSignedDataMsg", "CryptSIPGetSignedDataMsg")] {
            let key = format!(r"{sip}\{k}\{{C689AAB8-8E78-11D0-8C47-00C04FC295EE}}");
            let (dll, f) = (reg(&key, "Dll"), reg(&key, "FuncName"));
            if dll.is_empty() && f.is_empty() { continue; }
            if !dll.to_ascii_lowercase().ends_with("wintrust.dll") || !f.eq_ignore_ascii_case(func) {
                out.push(format!("{}PE SIP {k} → {dll}!{f}", if node.contains("WOW") { "32-bit " } else { "" }));
            }
        }
        let key = format!(r"{node}\Microsoft\Cryptography\Providers\Trust\FinalPolicy\{{00AAC56B-CD44-11D0-8CC2-00C04FC295EE}}");
        let (dll, f) = (reg(&key, "$DLL"), reg(&key, "$Function"));
        if !dll.is_empty() && (!dll.to_ascii_lowercase().ends_with("wintrust.dll") || !f.eq_ignore_ascii_case("SoftpubAuthenticode")) {
            out.push(format!("{}Authenticode final policy → {dll}!{f}", if node.contains("WOW") { "32-bit " } else { "" }));
        }
    }
    out
}

fn catalog(wp: &[u16]) -> Option<Check> {
    unsafe {
        let h = CreateFileW(wp.as_ptr(), 0x8000_0000, 7, null(), 3, 0, 0);
        if h == -1 { return None; }
        let sha256 = w("SHA256");
        let mut out = None;
        for alg in [sha256.as_ptr(), null()] {
            let mut admin = 0;
            if CryptCATAdminAcquireContext2(&mut admin, &DRIVER_ACTION_VERIFY, alg, null(), 0) == 0 { continue; }
            let (mut hash, mut cb) = ([0u8; 64], 64u32);
            if CryptCATAdminCalcHashFromFileHandle2(admin, h, &mut cb, hash.as_mut_ptr(), 0) != 0 {
                let cat = CryptCATAdminEnumCatalogFromHash(admin, hash.as_ptr(), cb, 0, null_mut());
                if cat != 0 {
                    let mut ci = CatalogInfo { cb: size_of::<CatalogInfo>() as u32, file: [0; 260] };
                    if CryptCATCatalogInfoFromContext(cat, &mut ci, 0) != 0 {
                        let tag = w(&hash[..cb as usize].iter().map(|b| format!("{b:02X}")).collect::<String>());
                        let info = CatInfo { cb: size_of::<CatInfo>() as u32, ver: 0, cat_path: ci.file.as_ptr(), tag: tag.as_ptr(), member: wp.as_ptr(),
                                             h, hash: hash.as_ptr(), cb_hash: cb, ctx: null(), admin };
                        let (rc, signer) = verify(2 /*WTD_CHOICE_CATALOG*/, &info as *const _ as _);
                        let sig = match classify(rc) { Sig::Unsigned => Sig::Invalid, s => s };
                        out = Some(Check { sig, signer, catalog: true });
                    }
                    CryptCATAdminReleaseCatalogContext(admin, cat, 0);
                }
            }
            CryptCATAdminReleaseContext(admin, 0);
            if out.is_some() { break; }
        }
        CloseHandle(h);
        out
    }
}

// ---- icons -------------------------------------------------------------------------------------

/// Small shell icon as RGBA (w, h, pixels). `generic` = icon for the ".exe" type without touching a file.
pub fn icon(path: &Path, generic: bool) -> Option<(usize, usize, Vec<u8>)> {
    unsafe {
        CoInitializeEx(null(), 2); // shell icons need COM on this thread
        let mut fi: ShFileInfo = std::mem::zeroed();
        let (p, attrs, flags) = if generic { (w(".exe"), 0x80, 0x100 | 0x1 | 0x10) } else { (w(&path.to_string_lossy()), 0, 0x100 | 0x1) };
        if SHGetFileInfoW(p.as_ptr(), attrs, &mut fi, size_of::<ShFileInfo>() as u32, flags) == 0 || fi.icon == 0 { return None; }
        let mut ii: IconInfo = std::mem::zeroed();
        let ok = GetIconInfo(fi.icon, &mut ii) != 0;
        DestroyIcon(fi.icon);
        if !ok { return None; }
        let dc = GetDC(0);
        let bits = |bmp: isize| -> Option<(usize, usize, Vec<u8>)> {
            let mut bm: Bitmap = std::mem::zeroed();
            if bmp == 0 || GetObjectW(bmp, size_of::<Bitmap>() as i32, &mut bm as *mut _ as _) == 0 { return None; }
            let (w, h) = (bm.w.max(0) as usize, bm.h.unsigned_abs() as usize);
            let mut hdr = BmiHeader { size: 40, w: w as i32, h: -(h as i32), planes: 1, bpp: 32, comp: 0, size_img: 0, xppm: 0, yppm: 0, used: 0, important: 0, colors: [0; 4] };
            let mut px = vec![0u8; w * h * 4];
            (GetDIBits(dc, bmp, 0, h as u32, px.as_mut_ptr().cast(), &mut hdr, 0) != 0).then_some((w, h, px))
        };
        let color = bits(ii.color);
        let mask = if color.as_ref().is_some_and(|c| c.2.chunks(4).all(|p| p[3] == 0)) { bits(ii.mask) } else { None };
        ReleaseDC(0, dc);
        DeleteObject(ii.color);
        DeleteObject(ii.mask);
        let (w, h, mut px) = color?;
        for (i, p) in px.chunks_mut(4).enumerate() {
            p.swap(0, 2); // BGRA -> RGBA
            if let Some(m) = &mask { p[3] = if m.2.get(i * 4).is_some_and(|&v| v == 0) { 255 } else { 0 }; }
        }
        Some((w, h, px))
    }
}

// ---- paths -------------------------------------------------------------------------------------

/// `\device\harddiskvolume3` -> `C:` for every drive letter.
pub fn dos_devices() -> Vec<(String, String)> {
    (b'A'..=b'Z').filter_map(|l| {
        let drive = format!("{}:", l as char);
        let mut buf = [0u16; 512];
        let n = unsafe { QueryDosDeviceW(w(&drive).as_ptr(), buf.as_mut_ptr(), 512) } as usize;
        let end = buf[..n].iter().position(|&c| c == 0).unwrap_or(n);
        (end > 0).then(|| (String::from_utf16_lossy(&buf[..end]).to_lowercase(), drive))
    }).collect()
}

/// What a SRUM app string refers to: display name, display path and the file on disk (if any).
pub struct Target { pub name: String, pub path: String, pub file: Option<PathBuf> }

pub fn resolve(raw: &str, devs: &[(String, String)]) -> Target {
    if let Some(cut) = raw.rfind('\\') {
        // "\Device\HarddiskVolume3\Windows\System32\svchost.exe [netsvcs]": strip the service group for the file
        let file = raw.find(" [").map_or(raw, |i| &raw[..i]);
        let lower = file.to_lowercase();
        let dos = devs.iter().find(|(d, _)| lower.starts_with(d.as_str()) && lower[d.len()..].starts_with('\\'))
            .map(|(d, drive)| format!("{drive}{}", &file[d.len()..]))
            .or_else(|| (file.as_bytes().get(1) == Some(&b':')).then(|| file.to_owned()));
        let path = dos.as_ref().map_or(raw.to_owned(), |d| format!("{d}{}", &raw[file.len()..]));
        return Target { name: raw[cut + 1..].to_owned(), path, file: dos.map(PathBuf::from) };
    }
    // packaged / legacy app ids: "Pkg_x64__id!App!app.exe!..." or "!!bash.exe!2026/..."
    let name = raw.split('!').find(|s| s.to_ascii_lowercase().ends_with(".exe")).or_else(|| raw.split('!').find(|s| !s.is_empty())).unwrap_or(raw);
    Target { name: name.to_owned(), path: if name == raw { String::new() } else { raw.to_owned() }, file: None }
}

// ---- cache + worker pool ---------------------------------------------------------------------------

/// Results keyed by lower-case path, valid while size + modified time match. Persisted between runs.
#[derive(Default)]
pub struct Cache { map: HashMap<String, (u64, u64, Check)>, dirty: bool }

fn cache_file() -> PathBuf {
    PathBuf::from(std::env::var_os("LOCALAPPDATA").unwrap_or_else(|| std::env::temp_dir().into())).join("AppCompatCacheParser").join("sigcache.tsv")
}

/// Bumped whenever verdicts can change for an unchanged file; older caches are discarded.
const CACHE_HEADER: &str = "#srumparser sigcache 2";

impl Cache {
    pub fn load() -> Cache {
        let mut c = Cache::default();
        let text = fs::read_to_string(cache_file()).unwrap_or_default();
        let mut lines = text.lines();
        if lines.next() != Some(CACHE_HEADER) { return c; }
        for l in lines {
            let f: Vec<&str> = l.split('\t').collect();
            if let [p, size, time, code, signer] = f[..] {
                let (Ok(size), Ok(time), Ok(code)) = (size.parse(), time.parse(), code.parse::<usize>()) else { continue };
                let Some(&sig) = Sig::ALL.get(code & 15) else { continue };
                c.map.insert(p.to_owned(), (size, time, Check { sig, signer: signer.to_owned(), catalog: code & 16 != 0 }));
            }
        }
        c
    }
    pub fn save(&mut self) {
        if !self.dirty { return; }
        let f = cache_file();
        let _ = fs::create_dir_all(f.parent().unwrap());
        if let Ok(mut out) = fs::File::create(f) {
            let _ = writeln!(out, "{CACHE_HEADER}");
            for (p, (size, time, c)) in &self.map {
                let code = Sig::ALL.iter().position(|&s| s == c.sig).unwrap_or(0) + if c.catalog { 16 } else { 0 };
                let _ = writeln!(out, "{p}\t{size}\t{time}\t{code}\t{}", c.signer.replace(['\t', '\n'], " "));
            }
        }
        self.dirty = false;
    }
}

/// Checks every distinct file on a few threads; `done(app_ids, check, icon)` fires per file.
pub fn run(files: Vec<(PathBuf, Vec<u32>)>, cache: &Mutex<Cache>, cancel: &AtomicBool, done: &(dyn Fn(&[u32], Check, Option<(usize, usize, Vec<u8>)>) + Sync)) {
    let next = AtomicUsize::new(0);
    let threads = std::thread::available_parallelism().map_or(4, |n| n.get()).clamp(2, 8);
    std::thread::scope(|s| {
        for _ in 0..threads {
            s.spawn(|| {
                loop {
                    let i = next.fetch_add(1, Relaxed);
                    let Some((path, apps)) = files.get(i) else { break };
                    if cancel.load(Relaxed) { break; }
                    let key = path.to_string_lossy().to_lowercase();
                    let meta = fs::metadata(path).ok();
                    let stamp = meta.as_ref().map(|m| (m.len(), m.modified().ok().and_then(|t| t.duration_since(UNIX_EPOCH).ok()).map_or(0, |d| d.as_secs())));
                    let cached = stamp.and_then(|st| cache.lock().unwrap().map.get(&key).filter(|e| (e.0, e.1) == st).map(|e| e.2.clone()));
                    let chk = cached.unwrap_or_else(|| {
                        let c = check(path);
                        if let Some((size, time)) = stamp {
                            let mut g = cache.lock().unwrap();
                            g.map.insert(key, (size, time, c.clone()));
                            g.dirty = true;
                        }
                        c
                    });
                    let ic = if chk.sig == Sig::NotFound { None } else { icon(path, false) };
                    done(apps, chk, ic);
                }
            });
        }
    });
    cache.lock().unwrap().save();
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn paths() {
        let devs = vec![(r"\device\harddiskvolume3".to_owned(), "C:".to_owned())];
        let t = resolve(r"\Device\HarddiskVolume3\Windows\System32\svchost.exe [netsvcs]", &devs);
        assert_eq!((t.name.as_str(), t.path.as_str()), ("svchost.exe [netsvcs]", r"C:\Windows\System32\svchost.exe [netsvcs]"));
        assert_eq!(t.file, Some(PathBuf::from(r"C:\Windows\System32\svchost.exe")));
        let t = resolve(r"\device\harddiskvolume9\x.exe", &devs);
        assert_eq!((t.path.as_str(), t.file), (r"\device\harddiskvolume9\x.exe", None));
        let t = resolve("Claude_2.1_x64__pzs!Claude!claude.exe!2026/10/07", &devs);
        assert_eq!((t.name.as_str(), t.file), ("claude.exe", None));
        let t = resolve("CryptSvc", &devs);
        assert_eq!((t.name.as_str(), t.path.as_str()), ("CryptSvc", ""));
    }

    #[test]
    fn signatures() {
        let sys = PathBuf::from(std::env::var("WINDIR").unwrap()).join("System32");
        assert_eq!(check(&sys.join("kernel32.dll")).sig, Sig::Signed); // embedded or catalog
        let n = check(&sys.join("notepad.exe"));
        assert_eq!(n.sig, Sig::Signed);
        assert!(n.signer.contains("Microsoft"), "{}", n.signer);
        assert_eq!(check(&sys.join("no-such-file.exe")).sig, Sig::NotFound);
        let tmp = std::env::temp_dir().join("srum-unsigned-test.exe");
        fs::write(&tmp, b"MZ not really a program").unwrap();
        assert_eq!(check(&tmp).sig, Sig::Unsigned);
        // embedded-signed file: digest matches; one patched code byte -> Tampered (even with a hijacked SIP)
        let explorer = PathBuf::from(std::env::var("WINDIR").unwrap()).join("explorer.exe");
        assert_eq!(digest_matches(&explorer), Some(true));
        let mut bytes = fs::read(&explorer).unwrap();
        bytes[0x1400] ^= 0xFF;
        fs::write(&tmp, &bytes).unwrap();
        assert_eq!(digest_matches(&tmp), Some(false));
        assert_eq!(check(&tmp).sig, Sig::Tampered);
        let _ = fs::remove_file(tmp);
        assert!(icon(&sys.join("notepad.exe"), false).is_some_and(|(w, h, px)| w > 0 && px.len() == w * h * 4));
    }
}
