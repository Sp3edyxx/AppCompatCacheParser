//! AppCompatCache (ShimCache): read the value from the live registry or an offline SYSTEM hive, parse every
//! known layout (XP, 7, 8, 8.1, 10, 10 1703+ / 11) and stream the entries that are real paths.
use crate::win::{self, w};
use std::{fs, path::Path, ptr::null_mut, sync::atomic::{AtomicBool, Ordering}, time::Instant};

pub const DENIED: &str = "Access denied - run as Administrator";
/// Sort key / value of a NULL cell.
pub const NULL: i64 = i64::MIN;

/// Mirrors SrumParser's table specs: one table, no metric columns.
pub struct Spec { pub csv: &'static str, pub metrics: &'static [(&'static str, &'static str, &'static str)] }
pub const PAGES: [Spec; 1] = [Spec { csv: "AppCompatCache", metrics: &[] }];

/// Rows stored column-wise. Row i is cache position i; `hay` holds its "Last Modified" text ("ts\n").
#[derive(Default)]
pub struct Rows { pub utc: Vec<i64>, pub app: Vec<u32>, pub m: Vec<i64>, pub hay: String, pub end: Vec<u32> }

impl Rows {
    pub fn len(&self) -> usize { self.utc.len() }
    pub fn text(&self, i: usize) -> std::str::Split<'_, char> {
        let s = if i == 0 { 0 } else { self.end[i - 1] as usize };
        self.hay[s..self.end[i] as usize - 1].split('\x01')
    }
    pub fn append(&mut self, mut o: Rows) {
        let base = self.hay.len() as u32;
        self.utc.append(&mut o.utc);
        self.app.append(&mut o.app);
        self.m.append(&mut o.m);
        self.hay.push_str(&o.hay);
        self.end.extend(o.end.iter().map(|e| e + base));
    }
}

/// `source`: control set + where it came from; `dirty`: offline hive with unreplayed .LOG data.
pub struct Info { pub source: String, pub format: String, pub offline: bool, pub dirty: bool }

pub enum Msg { Status(String), Info(Info), Apps(Vec<String>), Rows(usize, Rows), Done(f32), Fail(String) }

/// "1,234,567"
pub fn n0(v: i64, out: &mut String) {
    let mut d = [0u8; 20];
    let (mut u, mut i) = (v.unsigned_abs(), 20);
    loop { i -= 1; d[i] = b'0' + (u % 10) as u8; u /= 10; if u == 0 { break; } }
    if v < 0 { out.push('-'); }
    for (k, &c) in d[i..].iter().enumerate() {
        if k > 0 && (20 - i - k) % 3 == 0 { out.push(','); }
        out.push(c as char);
    }
}
pub fn n0s(v: usize) -> String { let mut s = String::new(); n0(v as i64, &mut s); s }

// ---- sources ------------------------------------------------------------------------------------

#[link(name = "advapi32", kind = "raw-dylib")]
unsafe extern "system" { fn RegGetValueW(key: isize, sub: *const u16, value: *const u16, flags: u32, typ: *mut u32, data: *mut u16, cb: *mut u32) -> i32; }

const HKLM: isize = 0x8000_0002u32 as i32 as isize;

/// One registry value from the 64-bit view of HKLM (RRF_RT_* type filter in `rt`).
fn reg(sub: &str, value: &str, rt: u32) -> Result<Vec<u8>, i32> {
    let (k, v) = (w(sub), w(value));
    let flags = rt | 0x0001_0000; // RRF_SUBKEY_WOW6464KEY
    let mut cb = 0u32;
    let rc = unsafe { RegGetValueW(HKLM, k.as_ptr(), v.as_ptr(), flags, null_mut(), null_mut(), &mut cb) };
    if rc != 0 { return Err(rc); }
    let mut buf = vec![0u8; cb as usize];
    let rc = unsafe { RegGetValueW(HKLM, k.as_ptr(), v.as_ptr(), flags, null_mut(), buf.as_mut_ptr().cast(), &mut cb) };
    if rc != 0 { return Err(rc); }
    buf.truncate(cb as usize);
    Ok(buf)
}

fn reg_err(rc: i32, what: &str) -> String { if rc == 5 { DENIED.into() } else { format!("{what} not found (error {rc})") } }

/// HKLM\SYSTEM\ControlSet00N\Control\Session Manager\AppCompatCache, N = Select\Current.
pub fn read_live() -> Result<(Vec<u8>, String), String> {
    let cur = reg(r"SYSTEM\Select", "Current", 0x10 /*DWORD*/).map_err(|e| reg_err(e, r"SYSTEM\Select\Current"))?;
    let cs = format!("ControlSet{:03}", u32::from_le_bytes(cur.get(..4).and_then(|b| b.try_into().ok()).unwrap_or([1, 0, 0, 0])));
    let base = format!(r"SYSTEM\{cs}\Control\Session Manager\");
    let blob = reg(&(base.clone() + "AppCompatCache"), "AppCompatCache", 0x8 /*BINARY*/)
        .or_else(|e| if e == 5 { Err(e) } else { reg(&(base + "AppCompatibility"), "AppCompatCache", 0x8) })
        .map_err(|e| reg_err(e, "AppCompatCache value"))?;
    Ok((blob, format!("{cs} (live)")))
}

/// Minimal read-only regf reader: walk keys by name and read one value (incl. big-data cells).
struct Hive { d: Vec<u8> }

impl Hive {
    fn u16(&self, o: usize) -> Result<usize, String> { Ok(u16::from_le_bytes(self.d.get(o..o + 2).ok_or("Hive truncated.")?.try_into().unwrap()) as usize) }
    fn u32(&self, o: usize) -> Result<u32, String> { Ok(u32::from_le_bytes(self.d.get(o..o + 4).ok_or("Hive truncated.")?.try_into().unwrap())) }
    fn sig(&self, o: usize, s: &[u8; 2]) -> bool { self.d.get(o..o + 2) == Some(s) }
    /// Record start (past the 4-byte cell size) for a cell offset relative to the first hbin.
    fn rec(&self, rel: u32) -> Result<usize, String> {
        let p = 0x1000usize + rel as usize + 4;
        if rel as i32 >= 0 && p + 4 <= self.d.len() { Ok(p) } else { Err("Hive cell offset out of range.".into()) }
    }
    fn name(&self, at: usize, len: usize, ascii: bool) -> Result<String, String> {
        let b = self.d.get(at..at + len).ok_or("Hive truncated.")?;
        Ok(if ascii { b.iter().map(|&c| c as char).collect() } else { String::from_utf16_lossy(&b.chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]])).collect::<Vec<_>>()) })
    }
    fn list(&self, l: usize, out: &mut Vec<usize>) -> Result<(), String> {
        let n = self.u16(l + 2)?;
        let step = if self.sig(l, b"lf") || self.sig(l, b"lh") { 8 } else if self.sig(l, b"li") || self.sig(l, b"ri") { 4 } else { return Err("Unknown subkey list type.".into()) };
        for i in 0..n {
            let c = self.rec(self.u32(l + 4 + i * step)?)?;
            if self.sig(l, b"ri") { self.list(c, out)?; } else { out.push(c); }
        }
        Ok(())
    }
    fn sub(&self, nk: usize, name: &str) -> Result<Option<usize>, String> {
        if !self.sig(nk, b"nk") { return Err("Expected key node.".into()); }
        if self.u32(nk + 0x14)? == 0 { return Ok(None); }
        let mut kids = vec![];
        self.list(self.rec(self.u32(nk + 0x1C)?)?, &mut kids)?;
        for k in kids {
            if self.name(k + 0x4C, self.u16(k + 0x48)?, self.u16(k + 2)? & 0x20 != 0)?.eq_ignore_ascii_case(name) { return Ok(Some(k)); }
        }
        Ok(None)
    }
    fn value(&self, nk: usize, name: &str) -> Result<Option<Vec<u8>>, String> {
        let count = self.u32(nk + 0x24)? as usize;
        if count == 0 { return Ok(None); }
        let list = self.rec(self.u32(nk + 0x28)?)?;
        for i in 0..count {
            let vk = self.rec(self.u32(list + i * 4)?)?;
            if !self.sig(vk, b"vk") { continue; }
            let nl = self.u16(vk + 2)?;
            if !self.name(vk + 0x14, nl, self.u16(vk + 0x10)? & 1 != 0)?.eq_ignore_ascii_case(name) { continue; }
            let raw = self.u32(vk + 4)?;
            if raw & 0x8000_0000 != 0 { // inline: up to 4 bytes in the offset field
                return Ok(Some(self.d.get(vk + 8..vk + 8 + (raw & 0x7FFF_FFFF).min(4) as usize).ok_or("Hive truncated.")?.to_vec()));
            }
            let (size, data) = (raw as usize, self.rec(self.u32(vk + 8)?)?);
            if size > 16344 && self.sig(data, b"db") { // big data: list of 16344-byte segments
                let (segs, l) = (self.u16(data + 2)?, self.rec(self.u32(data + 4)?)?);
                let mut buf = Vec::with_capacity(size);
                for s in 0..segs {
                    if buf.len() >= size { break; }
                    let seg = self.rec(self.u32(l + s * 4)?)?;
                    let take = 16344.min(size - buf.len());
                    buf.extend_from_slice(self.d.get(seg..seg + take).ok_or("Hive truncated.")?);
                }
                return Ok(Some(buf));
            }
            return Ok(Some(self.d.get(data..data + size).ok_or("Value data runs past end of hive.")?.to_vec()));
        }
        Ok(None)
    }
}

/// Offline SYSTEM hive: (blob, "ControlSet00N (file)", dirty).
pub fn read_hive(path: &Path) -> Result<(Vec<u8>, String, bool), String> {
    let h = Hive { d: fs::read(path).map_err(|e| if e.kind() == std::io::ErrorKind::PermissionDenied { DENIED.into() } else { e.to_string() })? };
    if h.d.len() < 0x1000 || h.u32(0)? != 0x6667_6572 { return Err("Not a registry hive (missing 'regf' header).".into()); }
    let dirty = h.u32(4)? != h.u32(8)?; // primary / secondary sequence mismatch = unreplayed .LOG data
    let root = h.rec(h.u32(0x24)?)?;
    let select = h.sub(root, "Select")?.ok_or("No 'Select' key: this is not a SYSTEM hive.")?;
    let cur = h.value(select, "Current")?.filter(|v| v.len() >= 4).ok_or(r"SYSTEM\Select\Current is missing.")?;
    let cs = format!("ControlSet{:03}", u32::from_le_bytes(cur[..4].try_into().unwrap()));
    let key = h.sub(root, &cs)?.ok_or(format!("{cs} not found in hive."))?;
    let key = h.sub(key, "Control")?.ok_or("Control key not found.")?;
    let sm = h.sub(key, "Session Manager")?.ok_or("Session Manager key not found.")?;
    let key = match h.sub(sm, "AppCompatCache")? { Some(k) => k, None => h.sub(sm, "AppCompatibility")?.ok_or("AppCompatCache key not found.")? };
    let blob = h.value(key, "AppCompatCache")?.ok_or("AppCompatCache value not found.")?;
    Ok((blob, format!("{cs} ({})", path.file_name().map_or(String::new(), |n| n.to_string_lossy().into_owned())), dirty))
}

// ---- parser ---------------------------------------------------------------------------------------

fn u16_at(d: &[u8], o: usize) -> Option<usize> { Some(u16::from_le_bytes(d.get(o..o + 2)?.try_into().ok()?) as usize) }
fn u32_at(d: &[u8], o: usize) -> Option<u32> { Some(u32::from_le_bytes(d.get(o..o + 4)?.try_into().ok()?)) }
fn u64_at(d: &[u8], o: usize) -> Option<u64> { Some(u64::from_le_bytes(d.get(o..o + 8)?.try_into().ok()?)) }
fn tag(d: &[u8], o: usize, t: &[u8; 4]) -> bool { d.get(o..o + 4) == Some(t) }
fn utf16(d: &[u8], o: usize, len: usize) -> Option<String> {
    Some(String::from_utf16_lossy(&d.get(o..o + len)?.chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]])).collect::<Vec<_>>()))
}

/// FILETIME -> UNIX seconds (NULL when unset or absurd).
fn filetime(ft: u64) -> i64 {
    if ft == 0 || ft > 2_650_467_743_999_999_999 { NULL } else { (ft / 10_000_000) as i64 - 11_644_473_600 }
}

/// Strips \??\ and \\?\ prefixes so the trust / existence checks see a plain drive path.
fn clean(p: String) -> String {
    let b = p.as_bytes();
    if (p.starts_with(r"\??\") || p.starts_with(r"\\?\")) && b.len() > 6 && b[5] == b':' { p[4..].to_owned() } else { p }
}

/// Real paths only (drive, UNC or SIGN.MEDIA label): drops UWP package records and binary rows.
fn is_path(s: &str) -> bool { s.chars().count() >= 4 && s.contains('\\') && !s.chars().any(char::is_control) }

/// (format name, [(last modified, path)] in cache order).
pub fn parse(d: &[u8]) -> Result<(&'static str, Vec<(i64, String)>), String> {
    let sig = u32_at(d, 0).filter(|_| d.len() >= 8).ok_or("AppCompatCache value is empty or truncated.")?;
    let mut out = vec![];
    let format = match sig {
        0xBADC_0FEE => { win7(d, &mut out); "Windows 7 / 2008 R2" }
        0xDEAD_BEEF => { winxp(d, &mut out); "Windows XP / 2003" }
        0x80 if tag(d, 0x80, b"00ts") => { win8(d, &mut out); "Windows 8 / 2012" }
        0x80 if tag(d, 0x80, b"10ts") => { win8(d, &mut out); "Windows 8.1 / 2012 R2" }
        0x30 | 0x34 if tag(d, sig as usize, b"10ts") => { win10(d, sig as usize, &mut out); if sig == 0x30 { "Windows 10" } else { "Windows 10 (1703+) / 11" } }
        _ => return Err(format!("Unrecognised AppCompatCache format (header 0x{sig:08X}). Vista / 2003 layouts are not supported.")),
    };
    out.retain(|e: &(i64, String)| is_path(&e.1));
    Ok((format, out))
}

// header | "10ts" unk(4) size(4) | pathLen(2) path | lastMod(8) | dataLen(4) data
fn win10(d: &[u8], mut off: usize, out: &mut Vec<(i64, String)>) -> Option<()> {
    while tag(d, off, b"10ts") {
        let end = off + 12 + u32_at(d, off + 8)? as usize;
        if end > d.len() { break; }
        let pl = u16_at(d, off + 12)?;
        if off + 14 + pl + 12 > end { break; }
        let path = clean(utf16(d, off + 14, pl)?);
        out.push((filetime(u64_at(d, off + 14 + pl)?), path));
        off = end;
    }
    Some(())
}

// header(0x80) | sig unk(4) size(4) | pathLen(2) path | pkgLen(2) pkg | insFlags(4) shimFlags(4) | lastMod(8) | dataLen(4) data
fn win8(d: &[u8], out: &mut Vec<(i64, String)>) -> Option<()> {
    let mut off = 0x80;
    while tag(d, off, b"00ts") || tag(d, off, b"10ts") {
        let end = off + 12 + u32_at(d, off + 8)? as usize;
        if end > d.len() { break; }
        let mut p = off + 12;
        let pl = u16_at(d, p)?;
        p += 2;
        if p + pl + 2 > end { break; }
        let path = clean(utf16(d, p, pl)?);
        p += pl;
        p += 2 + u16_at(d, p)? + 8; // package name, insert + shim flags
        if p + 12 > end { break; }
        out.push((filetime(u64_at(d, p)?), path));
        off = end;
    }
    Some(())
}

// header(0x80: sig, count) | fixed-size entries pointing into the blob for path / data
fn win7(d: &[u8], out: &mut Vec<(i64, String)>) -> Option<()> {
    let count = u32_at(d, 4)? as usize;
    let x64 = u32_at(d, 0x84)? == 0; // padding dword is zero only in the 64-bit layout
    let esz = if x64 { 48 } else { 32 };
    for i in 0..count {
        let o = 0x80 + i * esz;
        if o + esz > d.len() { break; }
        let pl = u16_at(d, o)?;
        let (path_off, ft) = if x64 { (u64_at(d, o + 8)? as usize, u64_at(d, o + 16)?) } else { (u32_at(d, o + 4)? as usize, u64_at(d, o + 8)?) };
        if let Some(path) = utf16(d, path_off, pl) { out.push((filetime(ft), clean(path))); }
    }
    Some(())
}

// header(0x190: sig, count) | 552-byte entries: path[528 UTF-16] lastMod(8) fileSize(8) lastUpdate(8)
fn winxp(d: &[u8], out: &mut Vec<(i64, String)>) -> Option<()> {
    let count = u32_at(d, 4)? as usize;
    for i in 0..count {
        let o = 0x190 + i * 552;
        if o + 552 > d.len() { break; }
        let mut len = 0;
        while len < 526 && (d[o + len] != 0 || d[o + len + 1] != 0) { len += 2; }
        out.push((filetime(u64_at(d, o + 528)?), clean(utf16(d, o, len)?)));
    }
    Some(())
}

// ---- loader -----------------------------------------------------------------------------------------

/// Reads `hive` (or the live registry when None) and streams everything through `send`.
pub fn load(hive: Option<&Path>, cancel: &AtomicBool, send: &dyn Fn(Msg)) {
    let t0 = Instant::now();
    let r = (|| -> Result<(), String> {
        send(Msg::Status("Reading AppCompatCache...".into()));
        let (blob, source, dirty) = match hive { Some(p) => read_hive(p)?, None => read_live().map(|(b, s)| (b, s, false))? };
        let (format, entries) = parse(&blob)?;
        send(Msg::Info(Info { source, format: format.into(), offline: hive.is_some(), dirty }));
        // distinct paths become the per-app table (signature, icon, tags are resolved once per path)
        let mut ids = std::collections::HashMap::new();
        let mut apps = vec![];
        let app: Vec<u32> = entries.iter().map(|(_, p)| *ids.entry(p.to_lowercase()).or_insert_with(|| { apps.push(p.clone()); apps.len() as u32 - 1 })).collect();
        send(Msg::Apps(apps));
        let mut tz = win::Tz::default();
        let mut b = Rows::default();
        for (i, (utc, _)) in entries.iter().enumerate() {
            if *utc != NULL { win::fmt_time(tz.local(*utc), &mut b.hay); }
            b.hay.push('\n');
            (b.utc.push(*utc), b.app.push(app[i]), b.end.push(b.hay.len() as u32));
            if b.len() == 2048 {
                if cancel.load(Ordering::Relaxed) { return Err(String::new()); }
                send(Msg::Rows(0, std::mem::take(&mut b)));
            }
        }
        if b.len() > 0 { send(Msg::Rows(0, b)); }
        Ok(())
    })();
    match r {
        Ok(()) => send(Msg::Done(t0.elapsed().as_secs_f32())),
        Err(e) if !e.is_empty() => send(Msg::Fail(e)),
        _ => {}
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn entry10(path: &str, ft: u64) -> Vec<u8> {
        let p: Vec<u8> = path.encode_utf16().flat_map(u16::to_le_bytes).collect();
        let body: Vec<u8> = [&(p.len() as u16).to_le_bytes()[..], &p, &ft.to_le_bytes(), &0u32.to_le_bytes()].concat();
        [&b"10ts"[..], &[0; 4], &(body.len() as u32).to_le_bytes(), &body].concat()
    }

    #[test]
    fn win10_layout() {
        let mut d = vec![0u8; 0x34];
        d[0] = 0x34;
        d.extend(entry10(r"\??\C:\Tools\a.exe", 133_000_000_000_000_000));
        d.extend(entry10("Microsoft.App_8wekyb3d8bbwe\tN", 0)); // UWP record: dropped
        d.extend(entry10(r"SIGN.MEDIA=1A2B Setup\setup.exe", 0));
        let (fmt, e) = parse(&d).unwrap();
        assert_eq!(fmt, "Windows 10 (1703+) / 11");
        assert_eq!(e, vec![(133_000_000_000_000_000 / 10_000_000 - 11_644_473_600, r"C:\Tools\a.exe".to_owned()), (NULL, r"SIGN.MEDIA=1A2B Setup\setup.exe".to_owned())]);
        assert!(parse(&[1, 2, 3, 4, 5, 6, 7, 8]).is_err());
    }

    #[test]
    fn live_registry_matches_export() {
        // needs Administrator; compares the live value with what `reg save` writes for the same hive
        let Ok((blob, src)) = read_live() else { return };
        assert!(src.ends_with("(live)"));
        let (fmt, entries) = parse(&blob).unwrap();
        assert!(fmt.starts_with("Windows") && !entries.is_empty());
        let hive = std::env::temp_dir().join("acc-test-SYSTEM.hiv");
        let _ = fs::remove_file(&hive);
        if std::process::Command::new("reg").args(["save", r"HKLM\SYSTEM", &hive.to_string_lossy(), "/y"]).output().is_ok_and(|o| o.status.success()) {
            let (b2, s2, _) = read_hive(&hive).unwrap();
            assert_eq!(s2.split(' ').next(), src.split(' ').next());
            assert_eq!(parse(&b2).unwrap().1, entries);
            let _ = fs::remove_file(hive);
        }
    }
}
