#![windows_subsystem = "windows"]
//! AppCompatCacheParser: ShimCache viewer with Sigcheck-style signature verification. Native Rust + egui.
mod shim;
mod sig;
mod win;

use eframe::egui::{
    self, pos2, text::LayoutJob, text::TextWrapping, vec2, Align, Align2, Button, CentralPanel, Color32, ColorImage, Context,
    CornerRadius, CursorIcon, Event, FontData, FontDefinitions, FontFamily, FontId, Frame, Id, Key, KeyboardShortcut, LayerId,
    Layout, Margin, Modifiers, Order, Painter, Panel, Rect, Response, ScrollArea, Sense, Shadow, Stroke, StrokeKind, TextEdit,
    TextureHandle, TextureOptions, Ui, UiBuilder, Vec2,
};
use raw_window_handle::{HasWindowHandle, RawWindowHandle};
use sig::{Check, Sig};
use shim::{n0s, Info, Msg, Rows, NULL, PAGES};
use std::{
    collections::HashMap,
    path::{Path, PathBuf},
    sync::{atomic::{AtomicBool, Ordering::Relaxed}, mpsc, Arc, Mutex},
    thread,
    time::Duration,
};

const fn c(h: u32) -> Color32 { Color32::from_rgb((h >> 16) as u8, (h >> 8) as u8, h as u8) }
const BG: Color32 = c(0x0D0E10);
const STRIPE: Color32 = c(0x121316);
const SEP: Color32 = c(0x1B1C20);
const FIELD: Color32 = c(0x16171A);
const BORDER: Color32 = c(0x25272C);
const HOVER: Color32 = c(0x1F2126);
const ROW_HOVER: Color32 = c(0x17191D);
const SEL: Color32 = c(0x16233A);
const FG: Color32 = c(0xE7E8EB);
const SUB: Color32 = c(0xBFC2C8);
const DIM: Color32 = c(0x8A8E97);
const HEAD: Color32 = c(0xA4A8B0);
const ACCENT: Color32 = c(0x3B82F6);
const PILL: Color32 = c(0x93C5FD);
const GREEN: Color32 = c(0x22C55E);
const RED: Color32 = c(0xEF4444);
const ROW_H: f32 = 28.0;
const HEAD_H: f32 = 30.0;
const PAD: f32 = 8.0;
const FIX: usize = 5; // Last Modified, Name, Path, Signature, Generics
const HEADS: [&str; FIX] = ["Last Modified", "Name", "Path", "Signature", "Generics"];
/// Sort "column" for the cache's own order (most recent insertion first), the default.
const POS: usize = usize::MAX;
/// Generics tags (bit i = TAGS[i]).
const TAGS: [(&str, &str); 2] = [("UNT", "Untrusted binary (unsigned, tampered, invalid, expired or revoked) outside the Windows and Program Files folders"),
                                 ("USB", "Run from removable media (SIGN.MEDIA entry, removable or CD drive)")];
fn tag_names(t: u8) -> String { TAGS.iter().enumerate().filter(|(i, _)| t >> i & 1 != 0).map(|(_, x)| x.0).collect::<Vec<_>>().join(" ") }
const SEARCH: &str = "search";
const SIG_ORDER: [Sig; 9] = [Sig::Signed, Sig::Tampered, Sig::Unsigned, Sig::Invalid, Sig::Expired, Sig::Revoked, Sig::NotFound, Sig::NoFile, Sig::Pending];

fn font(z: f32) -> FontId { FontId::proportional(z) }
fn bold(z: f32) -> FontId { FontId::new(z, FontFamily::Name("bold".into())) }
fn icons(z: f32) -> FontId { FontId::new(z, FontFamily::Name("icons".into())) }

fn sig_color(s: Sig) -> Color32 {
    match s {
        Sig::Signed => GREEN, Sig::Unsigned | Sig::Revoked | Sig::Tampered => RED, Sig::Invalid => c(0xF97316), Sig::Expired => c(0xF59E0B), _ => DIM,
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Act { Open, Live, Export, Admin, Find, Clear, FilterExe, Instance, Untrusted, NotFound, Copy, CopyPath, CopySigner, Reveal, SelectAll, Nav(i64, bool) }

/// One distinct cached path: resolved file, signature, icon. `odd` = outside the trusted folders,
/// `removable` = SIGN.MEDIA entry or removable / CD drive.
struct Exe { name: String, path: String, lc: String, sig: Sig, signer: String, catalog: bool, icon: Option<TextureHandle>, odd: bool, removable: bool }

enum SigMsg { Generic((usize, usize, Vec<u8>)), Done(Vec<u32>, Check, Option<(usize, usize, Vec<u8>)>) }

/// What a page rebuild filters and sorts by.
struct Filter<'a> { q: &'a str, scan: bool, hit: &'a [bool], boot: i64, allow: Option<&'a [bool]>, key: &'a [i64], keep: &'a [bool] }

/// The cache table: its rows, filtered + sorted view, selection and column layout.
struct Page { rows: Rows, nm: usize, view: Vec<u32>, sort: usize, asc: bool, widths: Vec<f32>, sel: Vec<bool>, nsel: usize, anchor: u32, cursor: Option<u32>, dirty: bool, scroll_to: Option<usize>, off: f32, vis: f32, total: usize }

impl Page {
    fn new(p: usize) -> Self {
        let m = PAGES[p].metrics;
        let widths = [150.0, 220.0, 300.0, 92.0, 104.0].into_iter().chain(m.iter().map(|m| (m.2.len() as f32 * 7.4 + 38.0).clamp(112.0, 150.0))).collect();
        Page { rows: Rows::default(), nm: m.len(), view: vec![], sort: POS, asc: true, widths, sel: vec![], nsel: 0, anchor: 0, cursor: None, dirty: false, scroll_to: None, off: 0.0, vis: 0.0, total: 0 }
    }

    /// Drops the loaded rows; keeps the column layout and sort.
    fn reset(&mut self) {
        (self.rows, self.view, self.sel) = (Rows::default(), vec![], vec![]);
        (self.nsel, self.cursor, self.dirty, self.scroll_to) = (0, None, false, None);
    }

    /// Filter + sort. Search hits come from the per-app table (`hit`) or one pass over the row text.
    fn rebuild(&mut self, f: &Filter) {
        self.dirty = false;
        let r = &self.rows;
        let n = r.len();
        let mut found = vec![];
        if f.scan {
            found = vec![false; n];
            let mut pos = 0;
            while let Some(i) = r.hay[pos..].find(f.q) {
                let i = r.end.partition_point(|&e| e as usize <= pos + i);
                found[i] = true;
                pos = r.end[i] as usize;
            }
        }
        let (mut v, mut total): (Vec<(i64, u32)>, usize) = (Vec::with_capacity(n), 0);
        for i in 0..n {
            let a = r.app[i] as usize;
            if !f.keep.is_empty() && !f.keep[a] { continue; } // entry without a path
            total += 1;
            if r.utc[i] < f.boot || f.allow.is_some_and(|al| !al[a]) || (!f.q.is_empty() && !f.hit[a] && !(f.scan && found[i])) { continue; }
            let key = match self.sort { POS => i as i64, 0 => r.utc[i], 1..FIX => f.key[a], c => r.m[i * self.nm + c - FIX] };
            v.push((key, i as u32));
        }
        v.sort_unstable(); // (key, row) is unique: stable order with row position as tie-break
        if !self.asc { v.reverse(); }
        (self.view, self.total) = (v.into_iter().map(|x| x.1).collect(), total);
    }

    fn pos(&self, row: u32) -> Option<usize> { self.view.iter().position(|&r| r == row) }

    /// Click / keyboard selection with Ctrl (toggle) and Shift (range from anchor).
    fn select(&mut self, vi: usize, ctrl: bool, shift: bool) {
        let row = self.view[vi];
        if shift {
            let a = self.pos(self.anchor).unwrap_or(vi);
            if !ctrl { self.sel.fill(false); }
            for j in a.min(vi)..=a.max(vi) { self.sel[self.view[j] as usize] = true; }
        } else {
            if !ctrl { self.sel.fill(false); }
            self.sel[row as usize] ^= true;
            self.anchor = row;
        }
        self.cursor = Some(row);
        self.nsel = self.sel.iter().filter(|&&b| b).count();
    }
}

struct App {
    pages: [Page; 1], view: usize,
    exes: Vec<Exe>, name_rank: Vec<i64>, path_rank: Vec<i64>, generic_icon: Option<TextureHandle>,
    devs: Vec<(String, String)>, cache: Arc<Mutex<sig::Cache>>, sig_left: usize, sig_total: usize, hijacks: Vec<String>,
    filter: String, applied: String, edited: Option<f64>, instance: bool, untrusted: bool, notfound: bool, boot: i64, admin: bool,
    tx: mpsc::Sender<(u64, Msg)>, rx: mpsc::Receiver<(u64, Msg)>, sig_tx: mpsc::Sender<(u64, SigMsg)>, sig_rx: mpsc::Receiver<(u64, SigMsg)>,
    epoch: u64, cancel: Arc<AtomicBool>,
    loading: bool, msg: String, err: bool, note: String, last: Option<PathBuf>, info: Option<Info>, secs: Option<f32>, rebuilt: f64,
    dlg_tx: mpsc::Sender<(bool, usize, Option<PathBuf>)>, dlg_rx: mpsc::Receiver<(bool, usize, Option<PathBuf>)>, dlg_busy: bool,
}

impl App {
    fn new(cc: &eframe::CreationContext) -> Self {
        let ctx = &cc.egui_ctx;
        setup(ctx);
        if let Ok(h) = cc.window_handle() {
            if let RawWindowHandle::Win32(h) = h.as_raw() { win::dark_title(h.hwnd.get(), 0x0D0E10); }
        }
        let ((tx, rx), (sig_tx, sig_rx), (dlg_tx, dlg_rx)) = (mpsc::channel(), mpsc::channel(), mpsc::channel());
        let mut app = App {
            pages: std::array::from_fn(Page::new), view: 0,
            exes: vec![], name_rank: vec![], path_rank: vec![], generic_icon: None,
            devs: sig::dos_devices(), cache: Arc::new(Mutex::new(sig::Cache::load())), sig_left: 0, sig_total: 0, hijacks: sig::hijacks(),
            filter: String::new(), applied: String::new(), edited: None, instance: false, untrusted: false, notfound: false,
            boot: win::boot(), admin: win::is_admin(),
            tx, rx, sig_tx, sig_rx, epoch: 0, cancel: Arc::new(AtomicBool::new(false)),
            loading: false, msg: String::new(), err: false, note: String::new(), last: None, info: None, secs: None, rebuilt: 0.0,
            dlg_tx, dlg_rx, dlg_busy: false,
        };
        // an offline SYSTEM hive from the command line, else this PC's live registry
        let hive = std::env::args_os().nth(1).map(PathBuf::from).filter(|p| p.is_file());
        app.load(ctx, hive);
        app
    }

    // ---- loading ------------------------------------------------------------------------

    fn fail(&mut self, e: String) { (self.msg, self.err, self.loading) = (e, true, false); }

    /// Reads the cache (live registry when `hive` is None) on a worker thread; rows stream in through the channel.
    fn load(&mut self, ctx: &Context, hive: Option<PathBuf>) {
        self.cancel.store(true, Relaxed);
        let cancel = Arc::new(AtomicBool::new(false));
        self.cancel = cancel.clone();
        self.epoch += 1;
        let (epoch, tx, c2, h2) = (self.epoch, self.tx.clone(), ctx.clone(), hive.clone());
        self.pages.iter_mut().for_each(Page::reset);
        (self.exes, self.name_rank, self.path_rank, self.info, self.secs) = (vec![], vec![], vec![], None, None);
        (self.sig_left, self.sig_total) = (0, 0);
        (self.loading, self.msg, self.err, self.note, self.last) = (true, "Starting...".into(), false, String::new(), hive);
        thread::spawn(move || shim::load(h2.as_deref(), &cancel, &|m| { let _ = tx.send((epoch, m)); c2.request_repaint(); }));
    }

    /// Resolves every cached path and starts the signature + icon workers. Offline hives describe another
    /// disk, so their files are not looked up here; network drives are skipped (a dead share blocks for seconds).
    fn start_sigs(&mut self, ctx: &Context, apps: Vec<String>) {
        let offline = self.last.is_some();
        let mut groups: HashMap<String, (PathBuf, Vec<u32>)> = HashMap::new();
        self.exes = apps.iter().enumerate().map(|(i, s)| {
            let t = sig::resolve(s, &self.devs);
            let drive = t.file.as_ref().map_or(0, |f| win::drive_type(f));
            let file = t.file.filter(|_| !offline && drive != 4 /*DRIVE_REMOTE*/);
            if let Some(f) = &file { groups.entry(f.to_string_lossy().to_lowercase()).or_insert_with(|| (f.clone(), vec![])).1.push(i as u32); }
            let sig = if file.is_some() { Sig::Pending } else { Sig::NoFile };
            let lower = s.to_lowercase();
            let rest = lower.get(3..).unwrap_or("");
            let odd = lower.as_bytes().get(1..3) == Some(b":\\") && (rest.starts_with(r"windows\temp\")
                || ![r"windows\", r"program files\", r"program files (x86)\"].iter().any(|r| rest.starts_with(r)));
            let removable = lower.starts_with("sign.media=") || (!offline && matches!(drive, 2 | 5)); // DRIVE_REMOVABLE, DRIVE_CDROM
            Exe { lc: format!("{}\x01{}", t.name, t.path).to_lowercase(), name: t.name, path: t.path, sig, signer: String::new(), catalog: false, icon: None, odd, removable }
        }).collect();
        let rank = |key: &dyn Fn(&Exe) -> &str| {
            let mut o: Vec<usize> = (0..self.exes.len()).collect();
            o.sort_by(|&x, &y| key(&self.exes[x]).chars().flat_map(char::to_uppercase).cmp(key(&self.exes[y]).chars().flat_map(char::to_uppercase)));
            let mut r = vec![0; o.len()];
            for (k, &i) in o.iter().enumerate() { r[i] = k as i64; }
            r
        };
        (self.name_rank, self.path_rank) = (rank(&|e| &e.name), rank(&|e| &e.path));
        let files: Vec<_> = groups.into_values().collect();
        (self.sig_left, self.sig_total) = (files.len(), files.len());
        let (tx, c2, cancel, cache, epoch) = (self.sig_tx.clone(), ctx.clone(), self.cancel.clone(), self.cache.clone(), self.epoch);
        thread::spawn(move || {
            if let Some(i) = sig::icon(Path::new(""), true) { let _ = tx.send((epoch, SigMsg::Generic(i))); }
            sig::run(files, &cache, &cancel, &|apps, chk, ic| { let _ = tx.send((epoch, SigMsg::Done(apps.to_vec(), chk, ic))); c2.request_repaint(); });
        });
    }

    fn poll(&mut self, ctx: &Context) {
        while let Ok((e, m)) = self.rx.try_recv() {
            if e != self.epoch { continue; }
            match m {
                Msg::Status(s) => self.msg = s,
                Msg::Info(i) => self.info = Some(i),
                Msg::Apps(a) => self.start_sigs(ctx, a),
                Msg::Rows(p, r) => {
                    let pg = &mut self.pages[p];
                    pg.rows.append(r);
                    pg.sel.resize(pg.rows.len(), false);
                    pg.dirty = true;
                }
                Msg::Done(s) => {
                    (self.loading, self.secs) = (false, Some(s));
                    self.msg.clear();
                    self.pages.iter_mut().for_each(|p| p.dirty = true);
                }
                Msg::Fail(e) => self.fail(e),
            }
        }
        let tex = |name: String, (w, h, px): (usize, usize, Vec<u8>)| ctx.load_texture(name, ColorImage::from_rgba_unmultiplied([w, h], &px), TextureOptions::LINEAR);
        while let Ok((e, m)) = self.sig_rx.try_recv() {
            if e != self.epoch { continue; }
            match m {
                SigMsg::Generic(i) => self.generic_icon = Some(tex("generic".into(), i)),
                SigMsg::Done(apps, chk, ic) => {
                    let t = ic.map(|i| tex(format!("ic{}", apps[0]), i));
                    for &a in &apps {
                        let x = &mut self.exes[a as usize];
                        (x.sig, x.signer, x.catalog, x.icon) = (chk.sig, chk.signer.clone(), chk.catalog, t.clone());
                    }
                    self.sig_left = self.sig_left.saturating_sub(1);
                    let sorted_by_sig = self.pages.iter().any(|p| matches!(p.sort, 3 | 4));
                    if self.untrusted || self.notfound || sorted_by_sig || !self.applied.is_empty() { self.pages.iter_mut().for_each(|p| p.dirty = true); }
                }
            }
        }
        while let Ok((save, p, r)) = self.dlg_rx.try_recv() {
            self.dlg_busy = false;
            match r { Some(f) if save => self.export(p, &f), Some(f) => self.load(ctx, Some(f)), None => {} }
        }
        let now = ctx.input(|i| i.time);
        if let Some(t) = self.edited {
            if now - t >= 0.15 { self.edited = None; self.apply_filter(); } else { ctx.request_repaint_after(Duration::from_secs_f64(0.15 - (now - t))); }
        }
        if self.pages.iter().any(|p| p.dirty) {
            // while rows / signatures stream in, re-sort at most every 150 ms
            if !(self.loading || self.sig_left > 0) || now - self.rebuilt > 0.15 { self.rebuild(false); self.rebuilt = now; } else { ctx.request_repaint_after(Duration::from_millis(150)); }
        }
    }

    fn apply_filter(&mut self) {
        self.applied = self.filter.trim().to_owned();
        self.pages.iter_mut().for_each(|p| p.dirty = true);
        self.rebuild(true);
    }

    /// Generics tags per path (bitmask over TAGS).
    fn generics(&self) -> Vec<u8> {
        self.exes.iter().map(|e| (e.sig.untrusted() && e.odd) as u8 | (e.removable as u8) << 1).collect()
    }

    fn rebuild(&mut self, clear: bool) {
        let q = self.applied.to_lowercase();
        let tags = self.generics();
        let hit: Vec<bool> = self.exes.iter().zip(&tags)
            .map(|(e, &g)| e.lc.contains(&q) || e.sig.label().to_lowercase().contains(&q) || (g != 0 && tag_names(g).to_lowercase().contains(&q))).collect();
        // timestamps and metrics are digits and " -:," only
        let scan = !q.is_empty() && q.bytes().all(|b| b.is_ascii_digit() || b" -:,".contains(&b));
        let boot = if self.instance { self.boot } else { NULL };
        let keep: Vec<bool> = self.exes.iter().map(|e| !e.path.is_empty()).collect(); // services, "System", bare package names
        let allow: Option<Vec<bool>> = (self.untrusted || self.notfound)
            .then(|| self.exes.iter().map(|e| (self.untrusted && e.sig.untrusted()) || (self.notfound && e.sig == Sig::NotFound)).collect());
        for p in 0..self.pages.len() {
            if !self.pages[p].dirty { continue; }
            let key: Vec<i64> = match self.pages[p].sort {
                1 => self.name_rank.clone(),
                2 => self.path_rank.clone(),
                3 => self.exes.iter().map(|e| SIG_ORDER.iter().position(|&s| s == e.sig).unwrap_or(0) as i64).collect(),
                4 => tags.iter().map(|&g| g as i64).collect(),
                _ => vec![],
            };
            let pg = &mut self.pages[p];
            pg.rebuild(&Filter { q: &q, scan, hit: &hit, boot, allow: allow.as_deref(), key: &key, keep: &keep });
            if clear { pg.sel.fill(false); pg.nsel = 0; }
        }
    }

    fn dialog(&mut self, save: bool, ctx: &Context) {
        let p = self.view;
        if self.dlg_busy || (save && self.pages[p].view.is_empty()) { return; }
        self.dlg_busy = true;
        let (owner, tx, c2) = (win::foreground(), self.dlg_tx.clone(), ctx.clone());
        thread::spawn(move || {
            let r = if save {
                win::file_dialog(true, owner, "Export view to CSV", "CSV file (*.csv)|*.csv|All files (*.*)|*.*|", "", &format!("{}_Output.csv", PAGES[p].csv))
            } else {
                win::file_dialog(false, owner, "Open offline SYSTEM hive", "SYSTEM hive|SYSTEM;*.hiv;*.dat|All files (*.*)|*.*|", "", "")
            };
            let _ = tx.send((save, p, r));
            c2.request_repaint();
        });
    }

    fn export(&mut self, p: usize, path: &Path) {
        match std::fs::write(path, csv(&self.pages[p], p, &self.exes, &self.generics())) {
            Ok(()) => self.note = format!("exported {} rows to {}", n0s(self.pages[p].view.len()), path.display()),
            Err(e) => self.fail(format!("Export failed: {e}")),
        }
    }

    fn selected(&self) -> Option<&Exe> {
        let pg = &self.pages[self.view];
        let r = pg.cursor.filter(|&r| pg.sel[r as usize])? as usize;
        self.exes.get(pg.rows.app[r] as usize)
    }

    fn act(&mut self, ctx: &Context, a: Act) {
        let p = self.view;
        let refilter = |s: &mut App| { s.pages.iter_mut().for_each(|p| p.dirty = true); s.rebuild(true); };
        match a {
            Act::Open => self.dialog(false, ctx),
            Act::Live => self.load(ctx, None),
            Act::Export => self.dialog(true, ctx),
            Act::Admin => if win::run_as_admin(self.last.as_deref()) { ctx.send_viewport_cmd(egui::ViewportCommand::Close) },
            Act::Find => ctx.memory_mut(|m| m.request_focus(Id::new(SEARCH))),
            Act::Clear => if !self.filter.is_empty() { self.filter.clear(); self.edited = None; self.apply_filter() },
            Act::FilterExe => if let Some(e) = self.selected().map(|e| if e.path.is_empty() { e.name.clone() } else { e.path.clone() }) {
                (self.filter, self.edited) = (e, None);
                self.apply_filter();
            },
            Act::Instance => { self.instance ^= true; refilter(self) }
            Act::Untrusted => { self.untrusted ^= true; refilter(self) }
            Act::NotFound => { self.notfound ^= true; refilter(self) }
            Act::CopyPath => if let Some(e) = self.selected() { ctx.copy_text(if e.path.is_empty() { e.name.clone() } else { e.path.clone() }) },
            Act::CopySigner => if let Some(e) = self.selected().filter(|e| !e.signer.is_empty()) { ctx.copy_text(e.signer.clone()) },
            Act::Reveal => if let Some(e) = self.selected().filter(|e| e.sig != Sig::NoFile && e.sig != Sig::NotFound) {
                let file = e.path.find(" [").map_or(e.path.as_str(), |i| &e.path[..i]);
                let _ = std::process::Command::new("explorer.exe").arg(format!("/select,{file}")).spawn();
            },
            Act::Copy => {
                // selected rows, tab-separated, no header
                let (pg, tags) = (&self.pages[p], self.generics());
                let mut s = String::new();
                for &i in pg.view.iter().filter(|&&i| pg.sel[i as usize]) {
                    let i = i as usize;
                    let (a, mut t) = (pg.rows.app[i] as usize, pg.rows.text(i));
                    let e = &self.exes[a];
                    s += &format!("{}\t{}\t{}\t{}\t{}", t.next().unwrap_or(""), e.name, e.path, e.sig.label(), tag_names(tags[a]));
                    for m in t { s.push('\t'); s += m; }
                    s += "\r\n";
                }
                if !s.is_empty() { ctx.copy_text(s); }
            }
            Act::SelectAll => {
                let pg = &mut self.pages[p];
                for &i in &pg.view { pg.sel[i as usize] = true; }
                pg.nsel = pg.sel.iter().filter(|&&b| b).count();
            }
            Act::Nav(d, shift) => {
                let pg = &mut self.pages[p];
                let n = pg.view.len() as i64;
                if n == 0 { return; }
                let step = ((pg.vis / ROW_H) as i64 - 1).max(1);
                let d = match d { -2 => -step, 2 => step, d => d };
                let vi = pg.cursor.and_then(|c| pg.pos(c)).map_or(0, |c| (c as i64).saturating_add(d).clamp(0, n - 1)) as usize;
                pg.select(vi, false, shift);
                pg.scroll_to = Some(vi);
            }
        }
    }

    fn shortcuts(&mut self, ctx: &Context, acts: &mut Vec<Act>) {
        let typing = ctx.memory(|m| m.has_focus(Id::new(SEARCH)));
        let (cmd, none, shift) = (Modifiers::COMMAND, Modifiers::NONE, Modifiers::SHIFT);
        ctx.input_mut(|i| {
            let keys = [(cmd, Key::O, Act::Open), (none, Key::F5, Act::Live), (cmd, Key::S, Act::Export), (cmd, Key::F, Act::Find),
                (cmd, Key::I, Act::Instance), (cmd, Key::E, Act::FilterExe), (none, Key::Escape, Act::Clear)];
            for (m, k, a) in keys { if i.consume_shortcut(&KeyboardShortcut::new(m, k)) { acts.push(a); } }
            if typing { return; }
            if i.consume_shortcut(&KeyboardShortcut::new(cmd, Key::A)) { acts.push(Act::SelectAll); }
            if i.events.iter().any(|e| matches!(e, Event::Copy)) { acts.push(Act::Copy); }
            let nav = [(Key::ArrowUp, -1), (Key::ArrowDown, 1), (Key::PageUp, -2), (Key::PageDown, 2), (Key::Home, i64::MIN), (Key::End, i64::MAX)];
            for (k, d) in nav {
                // Shift first: consume_key(NONE) ignores Shift and would take Shift+Arrow too
                for m in [shift, none] { if i.consume_key(m, k) { acts.push(Act::Nav(d, m == shift)); } }
            }
        });
    }

    // ---- toolbar ----------------------------------------------------------------------------------

    fn toolbar(&mut self, ui: &mut Ui, acts: &mut Vec<Act>) {
        Panel::top("bar").exact_size(40.0).show_separator_line(false).frame(Frame::NONE.fill(BG)).show(ui, |ui| {
            let r = ui.max_rect();
            let cy = r.center().y;
            if self.loading || self.sig_left > 0 { // thin sweeping progress line
                let t = (ui.input(|i| i.time) * 0.6).fract() as f32;
                let x = r.left() + (r.width() + 240.0) * t - 240.0;
                ui.painter().with_clip_rect(r).rect_filled(Rect::from_min_max(pos2(x, r.bottom() - 2.0), pos2(x + 240.0, r.bottom())), 1.0, ACCENT);
                ui.ctx().request_repaint();
            }

            // right: view + report buttons
            let mut rx = r.right() - 10.0;
            let live = self.last.is_none();
            let views = [("\u{EDE1}", "Export CSV", Act::Export, false, "Export the current view (Ctrl+S)"),
                ("\u{E8E5}", "Open Hive", Act::Open, !live, "Open an offline SYSTEM hive (Ctrl+O, or drop it on the window)"),
                ("\u{E7F4}", "Live Registry", Act::Live, live, "Read this PC's AppCompatCache (F5)")];
            for (ic, label, a, on, tip) in views {
                let w = ui.painter().layout_no_wrap(label.into(), font(12.5), FG).size().x + 40.0;
                let b = Rect::from_min_max(pos2(rx - w, cy - 13.0), pos2(rx, cy + 13.0));
                if tool_button(ui, b, ic, label, on).on_hover_text(tip).clicked() { acts.push(a); }
                rx = b.left() - 8.0;
            }

            // left: search, reload, toggles
            let toggles = [("In Instance", self.instance, Act::Instance, format!("Only files modified since this PC booted ({}) · Ctrl+I", local(self.boot))),
                ("Show Untrusted", self.untrusted, Act::Untrusted, "Only unsigned, tampered, invalid, expired or revoked binaries".into()),
                ("Show Not Found", self.notfound, Act::NotFound, "Only files that no longer exist on disk (live registry only)".into())];
            let tw: Vec<f32> = toggles.iter().map(|t| ui.painter().layout_no_wrap(t.0.into(), font(12.5), FG).size().x + 22.0).collect();
            let sr = Rect::from_min_size(pos2(r.left() + 10.0, cy - 13.0), vec2(290.0, 26.0));
            self.search(ui, sr, acts);
            let rb = Rect::from_center_size(pos2(sr.right() + 22.0, cy), Vec2::splat(26.0));
            let rr = ui.interact(rb, Id::new("reload"), Sense::click()).on_hover_text("Reload the live registry (F5)");
            ui.painter().text(rb.center(), Align2::CENTER_CENTER, "\u{E72C}", icons(14.0), if rr.hovered() { FG } else { SUB });
            if rr.clicked() { acts.push(Act::Live); }
            let mut x = rb.right() + 10.0;
            for ((label, on, a, tip), w) in toggles.into_iter().zip(tw) {
                if diamond(ui, Rect::from_min_size(pos2(x, cy - 12.0), vec2(w, 24.0)), label, on).on_hover_text(tip).clicked() { acts.push(a); }
                x += w + 8.0;
            }
            // the free space in between carries counts, progress and warnings
            self.status(ui, Rect::from_min_max(pos2(x + 16.0, r.top()), pos2(rx - 14.0, r.bottom())));
        });
    }

    fn search(&mut self, ui: &mut Ui, r: Rect, acts: &mut Vec<Act>) {
        let fid = Id::new(SEARCH);
        let focused = ui.memory(|m| m.has_focus(fid));
        ui.painter().rect(r, 6.0, FIELD, Stroke::new(1.0, if focused { ACCENT } else { BORDER }), StrokeKind::Inside);
        ui.painter().text(pos2(r.left() + 14.0, r.center().y), Align2::CENTER_CENTER, "\u{E721}", icons(11.0), if focused { ACCENT } else { DIM });
        let right = if self.filter.is_empty() { 10.0 } else { 28.0 };
        let te = Rect::from_min_max(pos2(r.left() + 27.0, r.top() + 4.0), pos2(r.right() - right, r.bottom() - 4.0));
        let resp = ui.put(te, TextEdit::singleline(&mut self.filter).id(fid).frame(Frame::NONE).margin(Margin::ZERO).font(font(12.5))
            .hint_text("Search shimcache entries...").desired_width(f32::INFINITY).vertical_align(Align::Center));
        if resp.changed() { self.edited = Some(ui.input(|i| i.time)); }
        if !self.filter.is_empty() {
            let x = Rect::from_center_size(pos2(r.right() - 15.0, r.center().y), Vec2::splat(18.0));
            let xr = ui.interact(x, Id::new("sx"), Sense::click()).on_hover_text("Clear (Esc)");
            cross(ui.painter(), x.center(), 3.5, if xr.hovered() { FG } else { DIM });
            if xr.clicked() { acts.push(Act::Clear); }
        }
    }

    // ---- table --------------------------------------------------------------------------------------

    fn table(&mut self, ui: &mut Ui, acts: &mut Vec<Act>) {
        let p = self.view;
        let area = ui.available_rect_before_wrap().shrink2(vec2(10.0, 0.0)); // 10 px side margins like the toolbar
        if self.pages[p].rows.len() == 0 {
            let (t, col) = if self.loading { ("Reading…", DIM) } else if self.err { (self.msg.as_str(), RED) } else { ("No entries. Drop a SYSTEM hive here or click Open Hive.", DIM) };
            ui.painter().text(area.center(), Align2::CENTER_CENTER, t, font(13.0), col);
            if self.err && self.msg == shim::DENIED && !self.admin {
                let b = Rect::from_center_size(area.center() + vec2(0.0, 36.0), vec2(200.0, 30.0));
                if tool_button(ui, b, "\u{E7EF}", "Restart as Administrator", false).clicked() { acts.push(Act::Admin); }
            }
            return;
        }
        let ncol = self.pages[p].nm + FIX;
        let w = &self.pages[p].widths;
        // Path takes all spare width; the grid scrolls sideways once columns no longer fit.
        let fixed: f32 = (0..ncol).filter(|&c| c != 2).map(|c| w[c]).sum();
        let ws: Vec<f32> = (0..ncol).map(|c| if c == 2 { (area.width() - ui.spacing().scroll.allocated_width() - fixed).max(w[2]) } else { w[c] }).collect();
        let total: f32 = ws.iter().sum();
        let mut child = ui.new_child(UiBuilder::new().max_rect(area).layout(Layout::top_down(Align::Min)));
        ScrollArea::horizontal().id_salt(("h", p)).auto_shrink(false).show(&mut child, |ui| {
            ui.spacing_mut().item_spacing = Vec2::ZERO;
            let (hr, _) = ui.allocate_exact_size(vec2(total, HEAD_H), Sense::hover());
            self.header(ui, hr, &ws);
            let pg = &mut self.pages[p];
            let mut sa = ScrollArea::vertical().id_salt(("v", p)).auto_shrink(false);
            if let Some(vi) = pg.scroll_to.take() {
                let y = vi as f32 * ROW_H;
                let off = if y < pg.off { y } else if y + ROW_H > pg.off + pg.vis { y + ROW_H - pg.vis } else { pg.off };
                sa = sa.vertical_scroll_offset(off);
            }
            let n = pg.view.len();
            let tags = self.generics();
            let out = sa.show_rows(ui, ROW_H, n, |ui, range| self.body(ui, range, &ws, total, &tags, acts));
            let pg = &mut self.pages[p];
            (pg.off, pg.vis) = (out.state.offset.y, out.inner_rect.height());
        });
        if self.pages[p].view.is_empty() {
            ui.painter().text(area.center(), Align2::CENTER_CENTER, "No matching entries.", font(13.0), DIM);
        }
    }

    fn header(&mut self, ui: &Ui, hr: Rect, ws: &[f32]) {
        let p = self.view;
        let pg = &mut self.pages[p];
        let painter = ui.painter();
        painter.hline(hr.x_range(), hr.top() + 0.5, Stroke::new(1.0, SEP));
        painter.hline(hr.x_range(), hr.bottom() - 0.5, Stroke::new(1.0, BORDER));
        let mut x = hr.left();
        let mut sort = None;
        for (c, &w) in ws.iter().enumerate() {
            let r = Rect::from_min_size(pos2(x, hr.top()), vec2(w, HEAD_H));
            let mut resp = ui.interact(r, Id::new(("hd", p, c)), Sense::click());
            let (name, right) = if c < FIX { (HEADS[c], false) } else { (PAGES[p].metrics[c - FIX].2, true) };
            if c >= FIX { resp = resp.on_hover_text(PAGES[p].metrics[c - FIX].0); }
            let on = pg.sort == c;
            let col = if on || resp.hovered() { FG } else { HEAD };
            let mut job = LayoutJob::simple_singleline(name.into(), bold(12.0), col);
            job.wrap = TextWrapping { max_width: w - PAD - 22.0, max_rows: 1, break_anywhere: true, overflow_character: Some('…') };
            let g = painter.layout_job(job);
            let gw = g.size().x;
            let tx = if right { r.right() - PAD - gw - if on { 16.0 } else { 0.0 } } else { r.left() + PAD };
            painter.with_clip_rect(r).galley(pos2(tx, r.center().y - g.size().y / 2.0), g, col);
            if on { // sort arrow at the right edge of the cell
                let (a, d) = (pos2(r.right() - 12.0, r.center().y), if pg.asc { 2.6 } else { -2.6 });
                painter.add(egui::Shape::convex_polygon(vec![a + vec2(-3.8, d), a + vec2(0.0, -d), a + vec2(3.8, d)], SUB, Stroke::NONE));
            }
            painter.vline(r.right() - 0.5, r.y_range(), Stroke::new(1.0, SEP));
            if resp.clicked() { sort = Some(c); }
            x += w;
        }
        // resize grips go on top of the header cells
        let mut x = hr.left();
        for (c, &w) in ws.iter().enumerate() {
            x += w;
            let g = ui.interact(Rect::from_center_size(pos2(x, hr.center().y), vec2(8.0, HEAD_H)), Id::new(("grip", p, c)), Sense::drag());
            if g.hovered() || g.dragged() {
                ui.ctx().set_cursor_icon(CursorIcon::ResizeHorizontal);
                painter.vline(x - 0.5, (hr.top() + 7.0)..=(hr.bottom() - 7.0), Stroke::new(1.0, BORDER));
            }
            if g.dragged() { pg.widths[c] = (w + g.drag_delta().x).max(56.0); sort = None; }
        }
        if let Some(c) = sort {
            // names, paths, signatures A-Z first; times, numbers and tags largest first
            if pg.sort == c { pg.asc ^= true; } else { (pg.sort, pg.asc) = (c, matches!(c, 1..=3)); }
            pg.dirty = true;
            self.rebuild(false);
        }
    }

    fn body(&mut self, ui: &mut Ui, range: std::ops::Range<usize>, ws: &[f32], total: f32, tags: &[u8], acts: &mut Vec<Act>) {
        let p = self.view;
        let pg = &self.pages[p];
        let mut click = None;
        for vi in range {
            let i = pg.view[vi] as usize;
            let a = pg.rows.app[i] as usize;
            let e = &self.exes[a];
            let (r, resp) = ui.allocate_exact_size(vec2(total, ROW_H), Sense::click());
            let on = pg.sel[i];
            let painter = ui.painter();
            let bg = if on { SEL } else if resp.hovered() { ROW_HOVER } else { BG };
            painter.rect_filled(r, 0.0, bg);
            if on { painter.rect_filled(Rect::from_min_size(r.min, vec2(2.0, ROW_H)), 0.0, ACCENT); }
            painter.hline(r.x_range(), r.bottom() - 0.5, Stroke::new(1.0, SEP));
            let mut t = pg.rows.text(i);
            let ts = t.next().unwrap_or("");
            let mut x = r.left();
            for (c, &w) in ws.iter().enumerate() {
                let cr = Rect::from_min_size(pos2(x, r.top()), vec2(w, ROW_H));
                painter.vline(cr.right() - 0.5, cr.y_range(), Stroke::new(1.0, SEP)); // faint column grid
                match c {
                    0 => cell(painter, cr, ts, false, SUB),
                    1 => cell(painter, cr, &e.name, false, FG),
                    2 => {
                        let ic = Rect::from_center_size(pos2(cr.left() + PAD + 8.0, cr.center().y), Vec2::splat(16.0));
                        let tex = e.icon.as_ref().or(if e.sig == Sig::NoFile { None } else { self.generic_icon.as_ref() });
                        if let Some(tex) = tex {
                            let tint = if e.sig == Sig::NotFound { Color32::from_white_alpha(110) } else { Color32::WHITE };
                            painter.image(tex.id(), ic, Rect::from_min_max(pos2(0.0, 0.0), pos2(1.0, 1.0)), tint);
                        }
                        cell(painter, cr.with_min_x(cr.left() + 22.0), &e.path, false, SUB);
                        if !e.path.is_empty() && resp.hovered() && ui.rect_contains_pointer(cr) {
                            let note = match (e.sig == Sig::NotFound, e.odd) {
                                (true, true) => "\nNot found on disk; outside trusted locations", (true, false) => "\nNot found on disk",
                                (false, true) => "\nOutside trusted locations", _ => "",
                            };
                            resp.clone().on_hover_text_at_pointer(format!("{}{note}", e.path));
                        }
                    }
                    3 => {
                        cell(painter, cr, e.sig.label(), false, sig_color(e.sig));
                        if resp.hovered() && ui.rect_contains_pointer(cr) && e.sig != Sig::NoFile { resp.clone().on_hover_text_at_pointer(sig_tip(e)); }
                    }
                    4 => {
                        let mut px = cr.left() + PAD;
                        for (k, (name, why)) in TAGS.iter().enumerate().filter(|(k, _)| tags[a] >> k & 1 != 0) {
                            let pr = pill(painter, pos2(px, cr.center().y), name);
                            if resp.hovered() && ui.rect_contains_pointer(pr.expand(2.0)) {
                                resp.clone().on_hover_text_at_pointer(if k == 0 { format!("{name}: {why}\nSignature: {}", e.sig.label()) } else { format!("{name}: {why}") });
                            }
                            px = pr.right() + 4.0;
                        }
                    }
                    _ => cell(painter, cr, t.next().unwrap_or(""), true, SUB),
                }
                x += w;
            }
            if resp.clicked() { click = Some((vi, ui.input(|i| i.modifiers))); }
            if resp.secondary_clicked() && !on { click = Some((vi, Modifiers::NONE)); }
            resp.context_menu(|ui| {
                ui.set_min_width(210.0);
                for (text, keys, a) in [("Copy", "Ctrl+C", Act::Copy), ("Copy Path", "", Act::CopyPath), ("Copy Signer", "", Act::CopySigner),
                                        ("Open File Location", "", Act::Reveal), ("Filter by This Exe", "Ctrl+E", Act::FilterExe), ("Select All", "Ctrl+A", Act::SelectAll)] {
                    if ui.add(Button::new(text).shortcut_text(keys)).clicked() { acts.push(a); ui.close(); }
                }
            });
        }
        if let Some((vi, m)) = click { self.pages[p].select(vi, m.command, m.shift); }
    }

    /// Counts, progress and red warnings, right-aligned in the toolbar's free space. Items are short and
    /// shown whole or not at all (least important dropped first); details live in their tooltips.
    fn status(&mut self, ui: &mut Ui, r: Rect) {
        let pg = &self.pages[self.view];
        // (id, label, font, colour, tooltip), most important first
        let mut items: Vec<(&str, String, FontId, Color32, String)> = vec![];
        if !self.hijacks.is_empty() {
            items.push(("hj", "⚠ Signature checks hijacked".into(), bold(11.5), RED, format!(
                "{}\n\nWindows would report any signature as valid. AppCompatCacheParser recomputes file digests itself, so Tampered results stay reliable.",
                self.hijacks.join("\n"))));
        }
        if self.info.as_ref().is_some_and(|i| i.dirty) {
            items.push(("dt", "⚠ Hive dirty".into(), bold(11.5), RED, "The hive's .LOG files were not replayed, so the newest changes may be missing.".into()));
        }
        let info = self.info.as_ref().map(|i| format!("{} · {}{}\nBoot {} · {}{}", i.source, i.format,
            self.secs.map_or(String::new(), |t| format!(" · loaded in {t:.2} s")), local(self.boot), if self.admin { "Administrator" } else { "not elevated" },
            if i.offline { "\nOffline hive: files are not looked up on this PC".into() } else if self.sig_total > 0 { format!("\n{} files checked offline", n0s(self.sig_total)) } else { String::new() }))
            .unwrap_or_default();
        if !self.msg.is_empty() {
            items.push(("st", self.msg.clone(), font(11.5), if self.err { RED } else { DIM }, if self.err { self.msg.clone() } else { info.clone() }));
        } else if pg.rows.len() > 0 {
            let filtered = !self.applied.is_empty() || self.instance || self.untrusted || self.notfound;
            let mut s = if filtered { format!("{} / {}", n0s(pg.view.len()), n0s(pg.total)) } else { format!("{} rows", n0s(pg.total)) };
            if pg.nsel > 0 { s += &format!(" · {} selected", n0s(pg.nsel)); }
            items.push(("st", s, font(11.5), DIM, if self.note.is_empty() { info.clone() } else { format!("{info}\n{}", self.note) }));
        }
        if self.sig_left > 0 {
            items.push(("sg", format!("Signatures {} / {}", n0s(self.sig_total - self.sig_left), n0s(self.sig_total)), font(11.5), DIM, "Checking signatures offline".into()));
        }
        let gap = 14.0;
        let measure = |items: &[(&str, String, FontId, Color32, String)]| -> Vec<f32> {
            items.iter().map(|it| ui.painter().layout_no_wrap(it.1.clone(), it.2.clone(), it.3).size().x).collect()
        };
        let fits = |w: &[f32]| w.iter().sum::<f32>() + gap * w.len().saturating_sub(1) as f32 <= r.width();
        let mut widths = measure(&items);
        if !fits(&widths) { // warnings shrink to a bare ⚠ before anything is dropped
            for it in items.iter_mut().filter(|it| it.3 == RED && it.1.starts_with('⚠')) { (it.1, it.2) = ("⚠".into(), bold(14.0)); }
            widths = measure(&items);
        }
        while !fits(&widths) { widths.pop(); }
        let mut x = r.right();
        for ((id, label, f, col, tip), w) in items.into_iter().zip(widths) {
            let wr = ui.painter().text(pos2(x, r.center().y), Align2::RIGHT_CENTER, label, f, col);
            ui.interact(wr, Id::new(id), Sense::hover()).on_hover_text(tip);
            x -= w + gap;
        }
    }
}

impl eframe::App for App {
    fn clear_color(&self, _: &egui::Visuals) -> [f32; 4] { BG.to_normalized_gamma_f32() }

    fn ui(&mut self, ui: &mut Ui, _: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();
        self.poll(&ctx);
        let mut acts = vec![];
        self.shortcuts(&ctx, &mut acts);
        self.toolbar(ui, &mut acts);
        CentralPanel::default().frame(Frame::NONE.fill(BG)).show(ui, |ui| self.table(ui, &mut acts));

        let screen = ui.max_rect();
        let fg = ctx.layer_painter(LayerId::new(Order::Foreground, Id::new("overlay")));
        let (hover, dropped) = ctx.input(|i| (!i.raw.hovered_files.is_empty(), i.raw.dropped_files.first().map(|f| f.path().to_path_buf())));
        if hover {
            fg.rect_filled(screen, 0.0, Color32::from_black_alpha(170));
            fg.text(screen.center(), Align2::CENTER_CENTER, "Drop an offline SYSTEM hive to open", bold(16.0), FG);
        }
        if let Some(p) = dropped { self.load(&ctx, Some(p)); }
        for a in acts { self.act(&ctx, a); }
    }
}

// ---- painting helpers ---------------------------------------------------------------------------

fn sig_tip(e: &Exe) -> String {
    let what = match e.sig {
        Sig::Pending => "Checking…",
        Sig::Signed if e.catalog => "Signed (Windows catalog)",
        Sig::Signed => "Signed (embedded Authenticode)",
        Sig::Unsigned => "No embedded or catalog signature",
        Sig::Invalid => "Signature does not verify (untrusted or broken certificate chain)",
        Sig::Tampered => "Signature does not match the file: it was patched after signing or the signature was copied from another file",
        Sig::Expired => "Signing certificate expired and the signature has no timestamp",
        Sig::Revoked => "Signing certificate revoked",
        Sig::NotFound => "File no longer exists at this path",
        Sig::NoFile => "",
    };
    if e.signer.is_empty() { what.into() } else { format!("{what}\nSigner: {}", e.signer) }
}

/// Current view of a page as CSV (raw numbers, local timestamps).
fn csv(pg: &Page, p: usize, exes: &[Exe], tags: &[u8]) -> String {
    let q = |s: &str| if s.contains([',', '"']) { format!("\"{}\"", s.replace('"', "\"\"")) } else { s.to_owned() };
    let mut s = String::with_capacity(pg.view.len() * 160);
    s += "Position,LastModified,Name,Path,Signature,Signer,Generics";
    for m in PAGES[p].metrics { s.push(','); s += &m.0.replace(' ', ""); }
    s += "\r\n";
    for &i in &pg.view {
        let i = i as usize;
        let a = pg.rows.app[i] as usize;
        let e = &exes[a];
        s += &format!("{i},{},{},{},{},{},{}", pg.rows.text(i).next().unwrap_or(""), q(&e.name), q(&e.path), e.sig.label(), q(&e.signer), tag_names(tags[a]));
        for &v in &pg.rows.m[i * pg.nm..(i + 1) * pg.nm] {
            s.push(',');
            if v != NULL { s += &v.to_string(); }
        }
        s += "\r\n";
    }
    s
}

fn local(utc: i64) -> String { let mut s = String::new(); win::fmt_time(win::Tz::default().local(utc), &mut s); s }

/// One grid cell, clipped with an ellipsis.
fn cell(p: &Painter, r: Rect, s: &str, right: bool, col: Color32) {
    if s.is_empty() { return; }
    let mut job = LayoutJob::simple_singleline(s.into(), font(12.5), col);
    job.wrap = TextWrapping { max_width: (r.width() - 2.0 * PAD).max(8.0), max_rows: 1, break_anywhere: true, overflow_character: Some('…') };
    let g = p.layout_job(job);
    let x = if right { r.right() - PAD - g.size().x } else { r.left() + PAD };
    p.with_clip_rect(r.intersect(p.clip_rect())).galley(pos2(x, r.center().y - g.size().y / 2.0), g, col);
}

/// Rounded, blue-outlined tag badge.
fn pill(p: &Painter, left_center: egui::Pos2, text: &str) -> Rect {
    let g = p.layout_no_wrap(text.into(), bold(9.5), PILL);
    let r = Rect::from_min_size(pos2(left_center.x, left_center.y - 8.0), vec2(g.size().x + 18.0, 16.0));
    p.rect(r, 8.0, c(0x14254A), Stroke::new(1.0, c(0x2F5FC4)), StrokeKind::Inside);
    p.galley(pos2(r.center().x - g.size().x / 2.0, r.center().y - g.size().y / 2.0), g, PILL);
    r
}

/// Dark rounded button with an icon glyph before the label.
fn tool_button(ui: &mut Ui, r: Rect, icon: &str, label: &str, on: bool) -> Response {
    let resp = ui.interact(r, Id::new(("tb", label, icon)), Sense::click());
    let (fill, stroke) = if on { (c(0x162036), c(0x2D4E8A)) } else if resp.hovered() { (HOVER, c(0x30333A)) } else { (FIELD, BORDER) };
    let p = ui.painter();
    p.rect(r, 7.0, fill, Stroke::new(1.0, stroke), StrokeKind::Inside);
    let ic_col = if on { PILL } else if resp.hovered() { FG } else { DIM };
    if label.is_empty() {
        p.text(r.center(), Align2::CENTER_CENTER, icon, icons(13.0), ic_col);
    } else {
        p.text(pos2(r.left() + 19.0, r.center().y), Align2::CENTER_CENTER, icon, icons(12.0), ic_col);
        p.text(pos2(r.left() + 31.0, r.center().y), Align2::LEFT_CENTER, label, font(12.5), if on || resp.hovered() { FG } else { SUB });
    }
    resp
}

/// Diamond-shaped checkbox with a label.
fn diamond(ui: &mut Ui, r: Rect, label: &str, on: bool) -> Response {
    let resp = ui.interact(r, Id::new(("dm", label)), Sense::click());
    let cen = pos2(r.left() + 7.0, r.center().y);
    let d = |h: f32| vec![cen + vec2(0.0, -h), cen + vec2(h, 0.0), cen + vec2(0.0, h), cen + vec2(-h, 0.0)];
    let p = ui.painter();
    p.add(egui::Shape::convex_polygon(d(6.0), Color32::TRANSPARENT, Stroke::new(1.3, if on || resp.hovered() { c(0x6EA0F8) } else { c(0x4A4E57) })));
    if on { p.add(egui::Shape::convex_polygon(d(3.2), ACCENT, Stroke::NONE)); }
    p.text(pos2(r.left() + 20.0, r.center().y), Align2::LEFT_CENTER, label, font(12.5), if on { FG } else if resp.hovered() { SUB } else { DIM });
    resp
}

fn cross(p: &Painter, c: egui::Pos2, h: f32, col: Color32) {
    let s = Stroke::new(1.3, col);
    p.line_segment([c + vec2(-h, -h), c + vec2(h, h)], s);
    p.line_segment([c + vec2(-h, h), c + vec2(h, -h)], s);
}

/// Window / taskbar icon: magnifier on an accent tile, rasterized with distance-field AA.
fn icon() -> egui::IconData {
    let n = 32usize;
    let cov = |d: f32| (0.5 - d).clamp(0.0, 1.0);
    let mut rgba = Vec::with_capacity(n * n * 4);
    for y in 0..n {
        for x in 0..n {
            let (px, py) = (x as f32 + 0.5, y as f32 + 0.5);
            let (qx, qy) = ((px - 16.0).abs() - 10.0, (py - 16.0).abs() - 10.0);
            let tile = cov((qx.max(0.0).hypot(qy.max(0.0)) + qx.max(qy).min(0.0)) - 6.0);
            let ring = cov(((px - 14.0).hypot(py - 14.0) - 7.2).abs() - 1.6);
            let (ax, ay, bx, by) = (19.2, 19.2, 25.0, 25.0);
            let t = (((px - ax) * (bx - ax) + (py - ay) * (by - ay)) / ((bx - ax).powi(2) + (by - ay).powi(2))).clamp(0.0, 1.0);
            let handle = cov((px - ax - t * (bx - ax)).hypot(py - ay - t * (by - ay)) - 2.0);
            let w = ring.max(handle);
            let mix = |a: u8| (a as f32 * (1.0 - w) + 255.0 * w) as u8;
            rgba.extend([mix(ACCENT.r()), mix(ACCENT.g()), mix(ACCENT.b()), (tile.max(w) * 255.0) as u8]);
        }
    }
    egui::IconData { rgba, width: n as u32, height: n as u32 }
}

/// Poppins (embedded) with Segoe UI / Segoe UI Symbol fallbacks and Segoe icon glyphs from the Windows font folder.
fn setup(ctx: &Context) {
    let dir = PathBuf::from(std::env::var("WINDIR").unwrap_or_else(|_| r"C:\Windows".into())).join("Fonts");
    let mut f = FontDefinitions::empty();
    f.font_data.insert("poppins".into(), Arc::new(FontData::from_static(include_bytes!("../assets/Poppins-Regular.ttf"))));
    f.font_data.insert("poppins-md".into(), Arc::new(FontData::from_static(include_bytes!("../assets/Poppins-Medium.ttf"))));
    let mut fam = |name: FontFamily, keys: &[&str]| { f.families.insert(name, keys.iter().map(|k| k.to_string()).collect()); };
    fam(FontFamily::Proportional, &["poppins", "ui", "sym"]);
    fam(FontFamily::Monospace, &["poppins", "ui", "sym"]);
    fam(FontFamily::Name("bold".into()), &["poppins-md", "ui", "sym"]);
    fam(FontFamily::Name("icons".into()), &["icons", "ui"]);
    for (key, files) in [("ui", &["segoeui.ttf", "arial.ttf"][..]), ("sym", &["seguisym.ttf"]), ("icons", &["SegoeIcons.ttf", "segmdl2.ttf"])] {
        match files.iter().find_map(|n| std::fs::read(dir.join(n)).ok()) {
            Some(b) => { f.font_data.insert(key.into(), Arc::new(FontData::from_owned(b))); }
            None => f.families.values_mut().for_each(|v| v.retain(|k| k != key)),
        }
    }
    ctx.set_fonts(f);
    ctx.set_theme(egui::Theme::Dark);
    ctx.all_styles_mut(|s| {
        use egui::TextStyle as T;
        s.text_styles = [(T::Small, 11.0), (T::Body, 12.5), (T::Button, 12.5), (T::Heading, 16.0), (T::Monospace, 12.5)].into_iter().map(|(t, z)| (t, font(z))).collect();
        s.spacing.item_spacing = vec2(6.0, 4.0);
        s.spacing.button_padding = vec2(10.0, 5.0);
        s.spacing.menu_margin = Margin::same(5);
        s.spacing.interact_size.y = 24.0;
        s.spacing.scroll = egui::style::ScrollStyle::solid();
        (s.spacing.scroll.bar_width, s.spacing.scroll.bar_inner_margin, s.spacing.scroll.bar_outer_margin) = (5.0, 2.0, 1.0);
        s.spacing.scroll.handle_min_length = 24.0;
        let v = &mut s.visuals;
        (v.panel_fill, v.window_fill, v.extreme_bg_color, v.faint_bg_color, v.hyperlink_color) = (BG, c(0x141518), BG, STRIPE, ACCENT);
        v.window_stroke = Stroke::new(1.0, BORDER);
        (v.window_corner_radius, v.menu_corner_radius) = (CornerRadius::same(8), CornerRadius::same(8));
        v.popup_shadow = Shadow { offset: [0, 4], blur: 14, spread: 0, color: Color32::from_black_alpha(160) };
        v.selection.bg_fill = c(0x1E3A6E);
        v.selection.stroke = Stroke::new(1.0, FG);
        v.text_cursor.stroke = Stroke::new(1.5, FG);
        let w = &mut v.widgets;
        (w.noninteractive.bg_stroke, w.noninteractive.fg_stroke, w.noninteractive.bg_fill) = (Stroke::new(1.0, SEP), Stroke::new(1.0, SUB), BG);
        // bg_fill: scrollbar handle · weak_bg_fill: buttons and menu items
        for (st, bg, weak, fg) in [(&mut w.inactive, c(0x2A2D33), FIELD, SUB), (&mut w.hovered, c(0x3A3E46), c(0x1C2B47), FG),
                                   (&mut w.active, c(0x4A4F59), c(0x22365C), FG), (&mut w.open, HOVER, HOVER, FG)] {
            (st.bg_fill, st.weak_bg_fill, st.fg_stroke, st.bg_stroke) = (bg, weak, Stroke::new(1.0, fg), Stroke::NONE);
            (st.corner_radius, st.expansion) = (CornerRadius::same(5), 0.0);
        }
    });
}

fn main() -> eframe::Result {
    // panic = "abort" leaves no trace on its own
    std::panic::set_hook(Box::new(|i| { let _ = std::fs::write(std::env::temp_dir().join("AppCompatCacheParser-crash.txt"), i.to_string()); }));
    let opts = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default().with_title("AppCompatCacheParser").with_inner_size([1460.0, 820.0]).with_min_inner_size([1000.0, 360.0])
            .with_drag_and_drop(true).with_icon(Arc::new(icon())),
        ..Default::default()
    };
    eframe::run_native("AppCompatCacheParser", opts, Box::new(|cc| Ok(Box::new(App::new(cc)))))
}


#[cfg(test)]
mod tests {
    use super::*;

    /// Cache rows in cache order: (last modified, path index).
    fn page() -> Page {
        let mut pg = Page::new(0);
        let mut r = Rows::default();
        for (utc, app) in [(300, 1), (100, 2), (200, 1), (NULL, 0)] {
            if utc != NULL { win::fmt_time(utc, &mut r.hay); }
            r.hay.push('\n');
            (r.utc.push(utc), r.app.push(app), r.end.push(r.hay.len() as u32));
        }
        pg.rows.append(r);
        pg.sel.resize(4, false);
        pg
    }

    fn f<'a>(q: &'a str, scan: bool, hit: &'a [bool], boot: i64, allow: Option<&'a [bool]>, key: &'a [i64]) -> Filter<'a> { Filter { q, scan, hit, boot, allow, key, keep: &[] } }

    #[test]
    fn filter_and_sort() {
        let mut pg = page();
        let rank = [0, 2, 1]; // "", "b.exe", "a.exe"
        let none = [false; 3];
        pg.rebuild(&f("", false, &none, NULL, None, &[]));
        assert_eq!(pg.view, [0, 1, 2, 3]); // default: cache order
        (pg.sort, pg.asc) = (0, false);
        pg.rebuild(&f("", false, &none, NULL, None, &[]));
        assert_eq!(pg.view, [0, 2, 1, 3]); // newest first, NULL last
        (pg.sort, pg.asc) = (1, true);
        pg.rebuild(&f("", false, &none, NULL, None, &rank));
        assert_eq!(pg.view, [3, 1, 0, 2]); // by name rank, row order breaks ties
        pg.rebuild(&f("00:0", true, &none, NULL, None, &rank)); // timestamps of rows 0..2
        assert_eq!(pg.view.len(), 3);
        pg.rebuild(&f("a.exe", false, &[false, false, true], NULL, None, &rank));
        assert_eq!(pg.view, [1]);
        pg.rebuild(&Filter { keep: &[false, true, true], ..f("", false, &none, NULL, None, &rank) }); // app 0 has no path
        assert_eq!((pg.view.len(), pg.total), (3, 3));
        pg.rebuild(&f("", false, &none, NULL, Some(&[false, true, false]), &rank)); // Show Untrusted / Not Found
        assert_eq!(pg.view, [0, 2]);
        (pg.sort, pg.asc) = (0, false);
        pg.rebuild(&f("", false, &none, 150, None, &[])); // In Instance: modified since boot, NULL excluded
        assert_eq!(pg.view, [0, 2]);
    }

    #[test]
    fn selection() {
        let mut pg = page();
        pg.rebuild(&f("", false, &[false; 3], NULL, None, &[]));
        pg.select(0, false, false);
        pg.select(2, false, true);
        assert_eq!((pg.nsel, pg.sel.clone()), (3, vec![true, true, true, false]));
        pg.select(1, true, false);
        assert_eq!(pg.nsel, 2);
        assert_eq!(pg.rows.text(1).collect::<Vec<_>>(), ["1970-01-01 00:01:40"]);
        assert_eq!(pg.rows.text(3).collect::<Vec<_>>(), [""]);
    }

    #[test]
    fn export_csv() {
        let mut pg = page();
        pg.rebuild(&f("", false, &[false; 3], NULL, None, &[]));
        let exe = |name: &str, path: &str, sig, signer: &str| Exe { name: name.into(), path: path.into(), lc: String::new(), sig, signer: signer.into(), catalog: false, icon: None, odd: false, removable: false };
        let exes = [exe("", "", Sig::NoFile, ""), exe("a,\"b\".exe", r"C:\a.exe", Sig::Unsigned, ""), exe("c.exe", r"E:\c.exe", Sig::Signed, "Contoso, Ltd")];
        assert_eq!(csv(&pg, 0, &exes, &[0, 1, 3]), "Position,LastModified,Name,Path,Signature,Signer,Generics\r\n\
            0,1970-01-01 00:05:00,\"a,\"\"b\"\".exe\",C:\\a.exe,Unsigned,,UNT\r\n\
            1,1970-01-01 00:01:40,c.exe,E:\\c.exe,Signed,\"Contoso, Ltd\",UNT USB\r\n\
            2,1970-01-01 00:03:20,\"a,\"\"b\"\".exe\",C:\\a.exe,Unsigned,,UNT\r\n3,,,,,,\r\n");
    }
}
