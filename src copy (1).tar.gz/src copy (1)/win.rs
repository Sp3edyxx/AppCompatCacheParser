//! Small Win32 helpers: local time, boot time, file dialogs, elevation.
use std::{collections::HashMap, ffi::c_void, fmt::Write, path::{Path, PathBuf}, ptr::null};

#[repr(C)]
#[derive(Default)]
struct SysTime { y: u16, mo: u16, _dow: u16, d: u16, h: u16, mi: u16, s: u16, _ms: u16 }

#[repr(C)]
struct Ofn {
    size: u32, owner: isize, inst: isize, filter: *const u16, cust: *mut u16, ncust: u32, index: u32,
    file: *mut u16, nfile: u32, ftitle: *mut u16, nftitle: u32, dir: *const u16, title: *const u16, flags: u32,
    foff: u16, fext: u16, defext: *const u16, data: isize, hook: isize, tmpl: *const u16, res: isize, res2: u32, flags_ex: u32,
}

#[link(name = "kernel32", kind = "raw-dylib")]
unsafe extern "system" {
    fn SystemTimeToTzSpecificLocalTime(tz: *const c_void, utc: *const SysTime, local: *mut SysTime) -> i32;
    fn OpenProcess(access: u32, inherit: i32, pid: u32) -> isize;
    fn GetProcessTimes(h: isize, create: *mut u64, exit: *mut u64, kernel: *mut u64, user: *mut u64) -> i32;
    fn CloseHandle(h: isize) -> i32;
    fn GetTickCount64() -> u64;
    fn GetDriveTypeW(root: *const u16) -> u32;
}
#[link(name = "comdlg32", kind = "raw-dylib")]
unsafe extern "system" {
    fn GetOpenFileNameW(o: *mut Ofn) -> i32;
    fn GetSaveFileNameW(o: *mut Ofn) -> i32;
}
#[link(name = "ole32", kind = "raw-dylib")]
unsafe extern "system" { fn CoInitializeEx(r: *const c_void, flags: u32) -> i32; }
#[link(name = "user32", kind = "raw-dylib")]
unsafe extern "system" { fn GetForegroundWindow() -> isize; }
#[link(name = "shell32", kind = "raw-dylib")]
unsafe extern "system" {
    fn IsUserAnAdmin() -> i32;
    fn ShellExecuteW(h: isize, op: *const u16, file: *const u16, args: *const u16, dir: *const u16, show: i32) -> isize;
}

#[link(name = "dwmapi", kind = "raw-dylib")]
unsafe extern "system" { fn DwmSetWindowAttribute(h: isize, attr: u32, v: *const c_void, cb: u32) -> i32; }

/// Dark native title bar (Windows 10 dark mode, Windows 11 caption / border colour).
pub fn dark_title(hwnd: isize, rgb: u32) {
    let bgr = (rgb & 0xFF) << 16 | (rgb & 0xFF00) | (rgb >> 16 & 0xFF);
    // DWMWA_USE_IMMERSIVE_DARK_MODE, BORDER_COLOR, CAPTION_COLOR, TEXT_COLOR
    for (attr, v) in [(20u32, 1u32), (34, bgr), (35, bgr), (36, 0x00EBE8E7)] {
        unsafe { DwmSetWindowAttribute(hwnd, attr, &v as *const u32 as _, 4); }
    }
}

/// NUL-terminated UTF-16.
pub fn w(s: &str) -> Vec<u16> { s.encode_utf16().chain([0]).collect() }

// Proleptic Gregorian <-> days since 1970-01-01 (H. Hinnant).
fn civil(z: i64) -> (i64, i64, i64) {
    let z = z + 719_468;
    let (era, doe) = (z.div_euclid(146_097), z.rem_euclid(146_097));
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    (yoe + era * 400 + (m <= 2) as i64, m, doy - (153 * mp + 2) / 5 + 1)
}
fn days(y: i64, m: i64, d: i64) -> i64 {
    let y = y - (m <= 2) as i64;
    let (era, yoe) = (y.div_euclid(400), y.rem_euclid(400));
    let doy = (153 * (if m > 2 { m - 3 } else { m + 9 }) + 2) / 5 + d - 1;
    era * 146_097 + yoe * 365 + yoe / 4 - yoe / 100 + doy - 719_468
}

/// UTC -> local (current time zone incl. its DST rules); offsets cached per hour.
#[derive(Default)]
pub struct Tz(HashMap<i64, i64>);
impl Tz {
    pub fn local(&mut self, utc: i64) -> i64 {
        utc + *self.0.entry(utc.div_euclid(3600)).or_insert_with(|| offset(utc.div_euclid(3600) * 3600))
    }
}
fn offset(t: i64) -> i64 {
    let (y, m, d) = civil(t.div_euclid(86_400));
    if !(1601..30_000).contains(&y) { return 0; }
    let s = t.rem_euclid(86_400);
    let u = SysTime { y: y as u16, mo: m as u16, d: d as u16, h: (s / 3600) as u16, mi: (s / 60 % 60) as u16, s: (s % 60) as u16, ..Default::default() };
    let mut l = SysTime::default();
    if unsafe { SystemTimeToTzSpecificLocalTime(null(), &u, &mut l) } == 0 { return 0; }
    days(l.y as i64, l.mo as i64, l.d as i64) * 86_400 + l.h as i64 * 3600 + l.mi as i64 * 60 + l.s as i64 - t
}

/// "yyyy-MM-dd HH:mm:ss"
pub fn fmt_time(t: i64, out: &mut String) {
    let (y, m, d) = civil(t.div_euclid(86_400));
    let s = t.rem_euclid(86_400);
    let _ = write!(out, "{y:04}-{m:02}-{d:02} {:02}:{:02}:{:02}", s / 3600, s / 60 % 60, s % 60);
}

pub fn now() -> i64 {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_or(0, |d| d.as_secs() as i64)
}

/// Boot time (UTC seconds) from the System process start; tick count as fallback.
pub fn boot() -> i64 {
    unsafe {
        let h = OpenProcess(0x1000, 0, 4);
        if h != 0 {
            let mut t = [0u64; 4];
            let [a, b, c, d] = &mut t;
            let ok = GetProcessTimes(h, a, b, c, d);
            CloseHandle(h);
            if ok != 0 && t[0] != 0 { return (t[0] / 10_000_000) as i64 - 11_644_473_600 - 30; }
        }
        now() - (GetTickCount64() / 1000) as i64
    }
}

/// GetDriveType of the path's drive letter (2 removable, 3 fixed, 4 remote, 5 CD); 0 for anything else.
pub fn drive_type(p: &Path) -> u32 {
    let s = p.to_string_lossy();
    if s.as_bytes().get(1) == Some(&b':') { unsafe { GetDriveTypeW(w(&format!("{}\\", &s[..2])).as_ptr()) } } else { 0 }
}

pub fn foreground() -> isize { unsafe { GetForegroundWindow() } }
pub fn is_admin() -> bool { unsafe { IsUserAnAdmin() != 0 } }

/// Common file dialog. `filter` is "Label|*.x|Label|*.y". Blocking: run it off the UI thread.
pub fn file_dialog(save: bool, owner: isize, title: &str, filter: &str, dir: &str, name: &str) -> Option<PathBuf> {
    let (filter, title, dir, ext) = (w(&filter.replace('|', "\0")), w(title), w(dir), w("csv"));
    let mut buf = vec![0u16; 4096];
    for (d, s) in buf.iter_mut().zip(name.encode_utf16()) { *d = s; }
    let mut o = Ofn {
        size: size_of::<Ofn>() as u32, owner, inst: 0, filter: filter.as_ptr(), cust: std::ptr::null_mut(), ncust: 0, index: 1,
        file: buf.as_mut_ptr(), nfile: buf.len() as u32, ftitle: std::ptr::null_mut(), nftitle: 0,
        dir: if dir.len() > 1 { dir.as_ptr() } else { null() }, title: title.as_ptr(),
        // EXPLORER | NOCHANGEDIR | PATHMUSTEXIST + (OVERWRITEPROMPT | FILEMUSTEXIST)
        flags: 0x80000 | 0x8 | 0x800 | if save { 0x2 } else { 0x1000 },
        foff: 0, fext: 0, defext: if save { ext.as_ptr() } else { null() }, data: 0, hook: 0, tmpl: null(), res: 0, res2: 0, flags_ex: 0,
    };
    let ok = unsafe {
        CoInitializeEx(null(), 2);
        if save { GetSaveFileNameW(&mut o) } else { GetOpenFileNameW(&mut o) }
    };
    let n = buf.iter().position(|&c| c == 0).unwrap_or(0);
    (ok != 0 && n > 0).then(|| PathBuf::from(String::from_utf16_lossy(&buf[..n])))
}

/// Relaunch this exe elevated (UAC prompt), optionally reopening `db`.
pub fn run_as_admin(db: Option<&Path>) -> bool {
    let Ok(exe) = std::env::current_exe() else { return false };
    let args = db.map(|p| format!("\"{}\"", p.display())).unwrap_or_default();
    let (op, exe, args) = (w("runas"), w(&exe.to_string_lossy()), w(&args));
    unsafe { ShellExecuteW(0, op.as_ptr(), exe.as_ptr(), args.as_ptr(), null(), 1) > 32 }
}

#[cfg(test)]
mod tests {
    #[test]
    fn calendar() {
        for d in [-800_000, -1, 0, 1, 19_000, 20_741, 2_000_000] {
            let (y, m, dd) = super::civil(d);
            assert_eq!(super::days(y, m, dd), d);
        }
        assert_eq!(super::days(2000, 3, 1), 11_017);
        let t = super::days(2026, 10, 15) * 86_400 + 11 * 3600 + 11 * 60;
        let mut s = String::new();
        super::fmt_time(t, &mut s);
        assert_eq!(s, "2026-10-15 11:11:00");
        // OLE date (days since 1899-12-30) of 11:11:02.4 rounds to :02, like the old reader
        let ole = (t + 2_209_161_600) as f64 / 86_400.0 + 2.4 / 86_400.0;
        assert_eq!((ole * 86_400.0).round() as i64 - 2_209_161_600, t + 2);
    }
}
